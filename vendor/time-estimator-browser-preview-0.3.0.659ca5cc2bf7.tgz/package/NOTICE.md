# Distribution and dependencies

This browser package is separate from the native time_estimator SDK and its Node worker client.
Newly authored project code has no selected redistribution license; this package remains private.
Local packing and application integration do not authorize publication.

Three.js is an optional peer under its own MIT license. Orca is an independently supplied
WebAssembly engine, not part of this package or the server SDK. Its code and browser port retain
their upstream AGPL notices and source obligations. The development fetch tools provision a
checksummed external slicing build only when requested; that slicing engine is not packed here.
The source-to-binary equivalence of that external build has not been established by this project.

The separate browser STL importer is bundled as a prebuilt WebAssembly module. It reuses the
source-matched C++ import program, Orca's retained ADMesh sources and Eigen 5.0.1. Their GPL,
AGPL, Eigen and Emscripten runtime license notices are in repair/licenses. Source/build identities are recorded in
repair/build.json; repair/README.md describes rebuilding from the complete source checkout.
This importer does not link or distribute the native/server estimator library.

Engine source: https://github.com/JoshTheDerf/orcaslicer-wasm
Orca source and license: https://github.com/OrcaSlicer/OrcaSlicer
Three.js source and license: https://github.com/mrdoob/three.js
