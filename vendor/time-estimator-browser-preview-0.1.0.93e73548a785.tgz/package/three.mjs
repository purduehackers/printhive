import * as THREE from 'three';
import { SEGMENT_STRIDE, SUPPORT_BASE, SUPPORT_INTERFACE } from './gcode.mjs';
import { requireValue } from './errors.mjs';

const faces = [0,2,1,0,3,2,4,5,6,4,6,7,0,1,5,0,5,4,1,2,6,1,6,5,2,3,7,2,7,6,3,0,4,3,4,7];

/** Batched rectangular-bead presentation of actual generated extrusion paths (not support generation). */
export function createSupportOverlay(preview, { baseColor = '#427f9e', interfaceColor = '#bc7031', chunkSegments = 4096 } = {}) {
  requireValue(preview?.schemaVersion === 1 && preview.segments instanceof Float64Array &&
    preview.segments.length % SEGMENT_STRIDE === 0, 'invalid_preview', 'Invalid support preview payload');
  requireValue(Number.isSafeInteger(chunkSegments) && chunkSegments > 0 && chunkSegments <= 65536,
    'invalid_preview', 'Invalid render chunk size');
  const group = new THREE.Group();
  group.name = 'generated-supports';
  const materials = new Map([
    [SUPPORT_BASE, new THREE.MeshStandardMaterial({ color: baseColor, roughness: 0.7, side: THREE.DoubleSide })],
    [SUPPORT_INTERFACE, new THREE.MeshStandardMaterial({ color: interfaceColor, roughness: 0.7, side: THREE.DoubleSide })],
  ]);
  const geometries = [];
  let disposed = false;
  try {
    for (const role of [SUPPORT_BASE, SUPPORT_INTERFACE]) {
      let positions = new Float32Array(chunkSegments * 24), indices = new Uint32Array(chunkSegments * 36), count = 0;
      const flush = () => {
        if (!count) return;
        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute('position', new THREE.BufferAttribute(positions.slice(0, count * 24), 3));
        geometry.setIndex(new THREE.BufferAttribute(indices.slice(0, count * 36), 1));
        geometry.computeVertexNormals(); geometry.computeBoundingSphere();
        geometries.push(geometry);
        const mesh = new THREE.Mesh(geometry, materials.get(role));
        mesh.name = role === SUPPORT_BASE ? 'support-base' : 'support-interface';
        group.add(mesh); count = 0;
      };
      const segments = preview.segments;
      for (let i = 0; i < segments.length; i += SEGMENT_STRIDE) {
        const [x0,y0,z0,x1,y1,z1,width,height,pathRole] = segments.subarray(i, i + SEGMENT_STRIDE);
        requireValue([x0,y0,z0,x1,y1,z1,width,height,pathRole].every(Number.isFinite) && width > 0 && height > 0 &&
          (pathRole === SUPPORT_BASE || pathRole === SUPPORT_INTERFACE), 'invalid_preview', 'Invalid support segment');
        if (pathRole !== role) continue;
        const length = Math.hypot(x1 - x0, y1 - y0);
        if (length < 1e-8) continue;
        requireValue(Math.abs(z1 - z0) < 1e-4, 'invalid_preview', 'Only planar support beads are supported');
        const dx = -(y1-y0) / length * width / 2, dy = (x1-x0) / length * width / 2;
        // printZ is the top of the physical layer, not the bead center.
        positions.set([x0+dx,y0+dy,z0-height,x1+dx,y1+dy,z1-height,x1-dx,y1-dy,z1-height,x0-dx,y0-dy,z0-height,
          x0+dx,y0+dy,z0,x1+dx,y1+dy,z1,x1-dx,y1-dy,z1,x0-dx,y0-dy,z0], count * 24);
        for (let k = 0; k < faces.length; ++k) indices[count * 36 + k] = count * 8 + faces[k];
        if (++count === chunkSegments) flush();
      }
      flush();
    }
  } catch (error) {
    for (const geometry of geometries) geometry.dispose();
    for (const material of materials.values()) material.dispose();
    throw error;
  }
  return {
    group,
    /** Requires renderer.localClippingEnabled; canonical Z is transformed into world coordinates. */
    setHeight(printZ = Infinity) {
      requireValue(printZ === Infinity || Number.isFinite(printZ), 'invalid_preview', 'Invalid clipping height');
      let sceneRoot = group;
      while (sceneRoot.parent) sceneRoot = sceneRoot.parent;
      sceneRoot.updateMatrixWorld(true);
      const planes = printZ === Infinity ? [] : [new THREE.Plane(new THREE.Vector3(0, 0, -1), printZ).applyMatrix4(group.matrixWorld)];
      for (const material of materials.values()) material.clippingPlanes = planes;
    },
    setVisible(visible) { group.visible = Boolean(visible); },
    dispose() {
      if (disposed) return;
      disposed = true; group.removeFromParent();
      for (const geometry of geometries) geometry.dispose();
      for (const material of materials.values()) material.dispose();
      group.clear();
    },
  };
}
