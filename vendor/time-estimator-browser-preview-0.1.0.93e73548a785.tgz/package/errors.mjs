export class PreviewError extends Error {
  constructor(code, message, details = {}) {
    super(message);
    this.name = 'PreviewError';
    this.code = code;
    this.details = details;
  }
}

export function requireValue(condition, code, message) {
  if (!condition) throw new PreviewError(code, message);
}

export const DEFAULT_LIMITS = Object.freeze({
  maxTriangles: 250_000,
  maxGcodeBytes: 64 * 1024 * 1024,
  maxSegments: 250_000,
  timeoutMs: 30_000,
});

export function limitsFor(options = {}) {
  const result = { ...DEFAULT_LIMITS, ...options };
  for (const [key, value] of Object.entries(result)) {
    requireValue(key in DEFAULT_LIMITS && Number.isSafeInteger(value) && value > 0,
      'invalid_limits', `Invalid preview limit: ${key}`);
  }
  return result;
}
