import { installSupportWorker } from './worker.mjs';
installSupportWorker();
