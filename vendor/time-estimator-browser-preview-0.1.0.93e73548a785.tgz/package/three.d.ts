import type { Group } from 'three';
import type { SupportPreview } from './index.js';
export interface SupportOverlay { group: Group; setHeight(printZ?: number): void; setVisible(visible: boolean): void; dispose(): void }
export function createSupportOverlay(preview: SupportPreview, options?: { baseColor?: string; interfaceColor?: string; chunkSegments?: number }): SupportOverlay;
