import { PreviewError, limitsFor } from './errors.mjs';
export { PreviewError, DEFAULT_LIMITS } from './errors.mjs';

/** One active request per client. Cancel destroys the worker, including its WASM heap. */
export function createPreviewClient({ manifestUrl, workerFactory, limits } = {}) {
  const defaults = limitsFor(limits);
  let worker = null, pending = null, sequence = 0, disposed = false;
  function stop(code = 'canceled', message = 'Support preview canceled') {
    worker?.terminate(); worker = null;
    if (pending) { clearTimeout(pending.timer); pending.reject(new PreviewError(code, message)); pending = null; }
  }
  return {
    async generate(request, { onProgress } = {}) {
      if (disposed) return Promise.reject(new PreviewError('disposed', 'The preview client is disposed'));
      stop();
      const budget = limitsFor({ ...defaults, ...request.limits });
      return new Promise((resolve, reject) => {
        const id = ++sequence;
        try {
          worker = workerFactory ? workerFactory() : new Worker(new URL('./worker-entry.mjs', import.meta.url), { type: 'module' });
          const timer = setTimeout(() => {
            if (pending?.id === id) stop('timeout', 'Support generation exceeded its browser time budget');
          }, budget.timeoutMs);
          pending = { id, resolve, reject, timer };
          worker.onmessage = ({ data }) => {
            if (!pending || pending.id !== id || data.id !== id) return;
            if (data.type === 'progress') { onProgress?.(data.progress); return; }
            const active = pending;
            clearTimeout(active.timer); pending = null;
            worker?.terminate(); worker = null;
            if (data.type === 'result') active.resolve(data.result);
            else active.reject(new PreviewError(data.error?.code ?? 'worker_error', data.error?.message ?? 'Support worker failed', data.error?.details));
          };
          worker.onerror = () => { if (pending?.id === id) stop('worker_error', 'The support worker could not run'); };
          worker.onmessageerror = () => { if (pending?.id === id) stop('worker_error', 'Invalid support worker reply'); };
          worker.postMessage({ id, request: { ...request, limits: budget }, manifestUrl });
        } catch (error) {
          stop('worker_error', 'Could not start the support worker');
          reject(error instanceof PreviewError ? error : new PreviewError('worker_error', 'Could not start the support worker', { reason: String(error) }));
        }
      });
    },
    cancel() { stop(); },
    dispose() { disposed = true; stop(); },
  };
}
