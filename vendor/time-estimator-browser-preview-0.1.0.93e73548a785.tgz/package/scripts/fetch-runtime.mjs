import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve, basename } from 'node:path';
import { fileURLToPath } from 'node:url';

const lock = JSON.parse(await readFile(new URL('../runtime.lock.json', import.meta.url)));
const destination = resolve(process.argv[2] ?? fileURLToPath(new URL('../../.work/browser-preview-runtime', import.meta.url)));
await mkdir(destination, { recursive: true });
for (const asset of [lock.module, lock.wasm, lock.data]) {
  if (basename(asset.file) !== asset.file) throw new Error('Invalid runtime basename');
  const path = resolve(destination, asset.file);
  const hash = bytes => createHash('sha256').update(bytes).digest('hex');
  try {
    const existing = await readFile(path);
    if (hash(existing) !== asset.sha256) throw new Error(`Existing runtime differs: ${path}`);
    continue;
  } catch (error) { if (error.code !== 'ENOENT') throw error; }
  const response = await fetch(asset.url);
  if (!response.ok) throw new Error(`Runtime download failed: ${asset.file} (${response.status})`);
  const bytes = new Uint8Array(await response.arrayBuffer());
  if (hash(bytes) !== asset.sha256) throw new Error(`Runtime checksum mismatch: ${asset.file}`);
  await writeFile(path, bytes, { flag: 'wx' });
}
await writeFile(resolve(destination, 'manifest.json'), JSON.stringify(lock, null, 2) + '\n');
console.log(`Browser runtime: ${destination}`);
