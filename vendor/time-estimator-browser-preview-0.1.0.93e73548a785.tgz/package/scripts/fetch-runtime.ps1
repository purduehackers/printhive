[CmdletBinding()]
param([string]$OutputDirectory = (Join-Path $PSScriptRoot '../../.work/browser-preview-runtime'))
$ErrorActionPreference = 'Stop'
$previewLock = Get-Content -LiteralPath (Join-Path $PSScriptRoot '../runtime.lock.json') -Raw | ConvertFrom-Json
$previewDestination = [IO.Path]::GetFullPath($OutputDirectory)
New-Item -ItemType Directory -Force -Path $previewDestination | Out-Null
foreach ($previewAsset in @($previewLock.module, $previewLock.wasm, $previewLock.data)) {
    if ([IO.Path]::GetFileName($previewAsset.file) -ne $previewAsset.file) { throw 'Invalid asset basename.' }
    $previewAssetPath = Join-Path $previewDestination $previewAsset.file
    if ((Test-Path -LiteralPath $previewAssetPath) -and
        (Get-FileHash -LiteralPath $previewAssetPath -Algorithm SHA256).Hash.ToLower() -eq $previewAsset.sha256) { continue }
    if (Test-Path -LiteralPath $previewAssetPath) { throw "Existing runtime asset differs: $previewAssetPath" }
    $previewTemporary = $previewAssetPath + '.download-' + [guid]::NewGuid().ToString('N')
    try {
        Invoke-WebRequest -UseBasicParsing -Uri $previewAsset.url -OutFile $previewTemporary
        if ((Get-FileHash -LiteralPath $previewTemporary -Algorithm SHA256).Hash.ToLower() -ne $previewAsset.sha256) {
            throw "Runtime checksum mismatch: $($previewAsset.file). Refusing a silently changed upstream binary."
        }
        Move-Item -LiteralPath $previewTemporary -Destination $previewAssetPath
    } finally {
        if (Test-Path -LiteralPath $previewTemporary) { Remove-Item -LiteralPath $previewTemporary }
    }
}
$previewLock | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $previewDestination 'manifest.json') -Encoding UTF8
Write-Output "Browser runtime: $previewDestination"
