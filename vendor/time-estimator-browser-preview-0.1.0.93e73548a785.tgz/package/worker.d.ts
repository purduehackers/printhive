import type { Mesh, Limits } from './index.js';
export function installSupportWorker<T = Mesh>(options?: { decodeMesh?: (input: T, limits: Limits) => Promise<Mesh> }): void;
