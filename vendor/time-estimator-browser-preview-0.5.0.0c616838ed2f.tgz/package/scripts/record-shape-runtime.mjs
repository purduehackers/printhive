import { readFile, writeFile, mkdir, copyFile, readdir } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve, dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';

const project = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const port = resolve(process.argv[2]);
const destination = resolve(process.argv[3] ?? join(project, 'browser/shapes/runtime'));
const hash = async path => createHash('sha256').update(await readFile(path)).digest('hex');
const sourceFiles = ['browser/shapes/ShapePreview.hpp', 'browser/shapes/timing.hpp', 'browser/shapes/timing.cpp',
  'browser/shapes/orca-wasm-shapes.patch', 'browser/shapes/bridge-shapes.patch',
  'src/cpp/fast.cpp', 'src/cpp/fast.hpp', 'src/cpp/io.cpp', 'src/cpp/geometry.cpp',
  'include/time_estimator/time_estimator.hpp'];
const sources = Object.fromEntries(await Promise.all(sourceFiles.map(async file => [file, await hash(join(project, file))])));
for (const file of sourceFiles.filter(file => !file.endsWith('.patch'))) {
  const staged = file.startsWith('browser/shapes/') ? join(port, 'bridge', file.split('/').at(-1))
    : file.startsWith('src/cpp/') ? join(port, 'time-estimator/src', file.split('/').at(-1))
    : join(port, 'time-estimator', file);
  if (await hash(staged) !== sources[file]) throw new Error(`Staged build source differs: ${file}`);
}
const assets = {};
for (const [key, extension] of [['module', 'mjs'], ['wasm', 'wasm'], ['data', 'data']]) {
  const file = `slicer.${extension}`;
  assets[key] = { file, bundled: `shapes/runtime/${file}`, sha256: await hash(join(destination, file)) };
}
const manifest = {
  schemaVersion: 1, kind: 'orca-cubby-serial', engine: { name: 'orca', version: '2.4.2', bridge: 1 },
  sourceRevision: '8500fcdccaa10b5099ac20d252af3a7c560046f1',
  sourceRepository: 'https://github.com/OrcaSlicer/OrcaSlicer',
  bridgeSourceRevision: '873ad293b5efbedd78de7ae6cda8d40c76d958e6',
  supportShapesVersion: 1,
  qualification: 'Source-built serial browser engine with pre-toolpath support regions and approximate combined model/support timing. Physical accuracy is not calibrated.',
  builtAtUTC: new Date().toISOString(),
  ...assets,
};
const build = { schemaVersion: 1, emscripten: '6.0.10', emsdkRevision: 'd7b4130688bfa348392b921ab04015aa15c4f154',
  emscriptenRelease: '666337b525e673e769121856d175f6f52b8ead64', clipper2: '1.5.4', sources,
  compiler: execFileSync(join(port, 'toolchain/emsdk/upstream/emscripten/emcc'), ['--version'], { encoding: 'utf8' }).split('\n')[0],
  dependencies: { boost: '1.84.0', cgal: '5.6.3', gmp: '6.3.0', mpfr: '4.2.2', eigen: '5.0.1', json: 'Orca bundled' },
  runtime: Object.fromEntries(Object.entries(assets).map(([key, value]) => [key, value.sha256])),
};
const notices = join(project, 'browser/shapes/licenses');
await mkdir(notices, { recursive: true });
const licenses = [
  ['orca/LICENSE.txt', 'Orca-AGPL-3.0.txt'], ['LICENSE', 'Browser-port-LICENSE.txt'], ['NOTICE.md', 'Browser-port-NOTICE.md'],
  ['toolchain/src/boost_1_84_0/LICENSE_1_0.txt', 'Boost-LICENSE.txt'],
  ['toolchain/src/gmp-6.3.0/COPYING', 'GMP-COPYING.txt'], ['toolchain/src/gmp-6.3.0/COPYING.LESSERv3', 'GMP-LGPL-3.0.txt'],
  ['toolchain/src/mpfr-4.2.2/COPYING.LESSER', 'MPFR-LGPL.txt'],
  ['toolchain/src/eigen-5.0.1/COPYING.MPL2', 'Eigen-MPL-2.0.txt'],
  ['toolchain/src/cereal-1.3.2/LICENSE', 'cereal-LICENSE.txt'],
  ['toolchain/src/nlopt-2.9.1/COPYING', 'NLopt-COPYING.txt'],
];
for (const [source, name] of licenses) await copyFile(join(port, source), join(notices, name));
for (const [relative, prefix] of [
  ['toolchain/src/CGAL-5.6.3','CGAL'], ['orca/deps_src/qhull','qhull'], ['orca/deps_src/miniz','miniz'],
  ['orca/deps_src/mcut','mcut'], ['orca/deps_src/earcut','earcut'], ['orca/deps_src/libnest2d','libnest2d'],
  ['orca/deps_src/expat','expat'], ['toolchain/emsdk/upstream/emscripten/cache/ports/zlib/zlib-1.3.2','zlib'],
  ['toolchain/emsdk/upstream/emscripten/cache/ports/libpng/libpng-1.6.58','libpng'],
  ['toolchain/emsdk/upstream/emscripten/cache/ports/freetype/freetype-VER-2-14-3','freetype'],
]) {
  for (const entry of await readdir(join(port,relative),{withFileTypes:true}))
    if (entry.isFile() && /^(license|copying|copyright)/i.test(entry.name))
      await copyFile(join(port,relative,entry.name),join(notices,`${prefix}-${entry.name}.txt`));
}
const jsonHeader = await readFile(join(port,'orca/deps_src/nlohmann/json.hpp'),'utf8');
await writeFile(join(notices,'json-3.10.4-MIT.txt'),jsonHeader.slice(0,jsonHeader.indexOf('*/')+2)+'\n');
await copyFile(join(port,'toolchain/emsdk/upstream/emscripten/cache/ports/libjpeg/jpeg-9f/README'),join(notices,'libjpeg-README.txt'));
await writeFile(join(project, 'browser/shapes/build.json'), JSON.stringify(build, null, 2) + '\n');
await writeFile(join(project, 'browser/runtime.lock.json'), JSON.stringify(manifest, null, 2) + '\n');
await writeFile(join(destination, 'manifest.json'), JSON.stringify(manifest, null, 2) + '\n');
console.log(`Recorded source-built browser runtime: ${destination}`);
