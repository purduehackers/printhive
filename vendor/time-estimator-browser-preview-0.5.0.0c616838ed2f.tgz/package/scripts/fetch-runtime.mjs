import { readFile, writeFile, mkdir, rename, unlink } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { resolve, basename } from 'node:path';
import { fileURLToPath } from 'node:url';

const lock = JSON.parse(await readFile(new URL('../runtime.lock.json', import.meta.url)));
const replace = process.argv.includes('--replace');
const destination = resolve(process.argv.slice(2).find(value => value !== '--replace') ?? fileURLToPath(new URL('../../.work/browser-preview-runtime', import.meta.url)));
await mkdir(destination, { recursive: true });
for (const asset of [lock.module, lock.wasm, lock.data]) {
  if (basename(asset.file) !== asset.file) throw new Error('Invalid runtime basename');
  const path = resolve(destination, asset.file);
  const hash = bytes => createHash('sha256').update(bytes).digest('hex');
  try {
    const existing = await readFile(path);
    if (hash(existing) === asset.sha256) continue;
    if (!replace) throw new Error(`Existing runtime differs: ${path}; use --replace to update it`);
  } catch (error) { if (error.code !== 'ENOENT') throw error; }
  let bytes;
  if (asset.bundled) {
    if (!/^shapes\/runtime\/slicer\.(mjs|wasm|data)$/.test(asset.bundled)) throw new Error('Invalid bundled runtime path');
    bytes = await readFile(new URL(`../${asset.bundled}`, import.meta.url));
  } else {
    const response = await fetch(asset.url);
    if (!response.ok) throw new Error(`Runtime download failed: ${asset.file} (${response.status})`);
    bytes = new Uint8Array(await response.arrayBuffer());
  }
  if (hash(bytes) !== asset.sha256) throw new Error(`Runtime checksum mismatch: ${asset.file}`);
  const temporary = `${path}.staging-${process.pid}`;
  try {
    await writeFile(temporary, bytes, { flag: 'wx' });
    await rename(temporary, path);
  } finally {
    await unlink(temporary).catch(error => { if (error.code !== 'ENOENT') throw error; });
  }
}
await writeFile(resolve(destination, 'manifest.json'), JSON.stringify(lock, null, 2) + '\n');
console.log(`Browser runtime: ${destination}`);
