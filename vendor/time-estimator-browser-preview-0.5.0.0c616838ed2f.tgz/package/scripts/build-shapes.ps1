param([string]$Distribution='Ubuntu', [string]$BuildDirectory)
$ErrorActionPreference='Stop'
$scriptPath=(Resolve-Path (Join-Path $PSScriptRoot 'build-shapes.sh')).Path
$linuxScript=& wsl -d $Distribution --exec wslpath -a -u $scriptPath
if ($LASTEXITCODE -ne 0) {throw 'Could not access the Linux build environment'}
$arguments=@('-d',$Distribution,'--exec','bash',$linuxScript.Trim())
if ($BuildDirectory) {$arguments+=$BuildDirectory}
& wsl @arguments
if ($LASTEXITCODE -ne 0) {throw 'Browser support-shape engine build failed'}
