param([Parameter(Mandatory=$true)][string]$EmsdkRoot, [string]$DependencyRoot, [string]$BuildDirectory)
$ErrorActionPreference='Stop'
$taskRoot=(Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$compiler=Join-Path (Resolve-Path $EmsdkRoot).Path ('upstream/emscripten/' + $(if($IsWindows){'emcc.exe'}else{'emcc'}))
$version=& $compiler --version
if($LASTEXITCODE -ne 0 -or $version[0] -notmatch '6\.0\.13'){throw 'Use the pinned Emscripten 6.0.13 SDK'}
if (-not $DependencyRoot) {$DependencyRoot=Join-Path $taskRoot 'build/native/_deps'}
if (-not $BuildDirectory) {$BuildDirectory=Join-Path $taskRoot 'build/browser-fast'}
$toolchain=Join-Path (Resolve-Path $EmsdkRoot).Path 'upstream/emscripten/cmake/Modules/Platform/Emscripten.cmake'
& cmake -S (Join-Path $taskRoot 'browser/fast') -B $BuildDirectory -G Ninja -DCMAKE_BUILD_TYPE=Release "-DCMAKE_TOOLCHAIN_FILE=$toolchain" "-DTE_DEPS=$DependencyRoot"
if ($LASTEXITCODE -ne 0) {throw 'Fast browser configuration failed'}
& cmake --build $BuildDirectory --parallel 2
if ($LASTEXITCODE -ne 0) {throw 'Fast browser compilation failed'}
$destination=Join-Path $taskRoot 'browser/fast'
Copy-Item -LiteralPath (Join-Path $BuildDirectory 'fast-estimator.mjs') -Destination $destination
New-Item -ItemType Directory -Force (Join-Path $destination 'licenses') | Out-Null
Copy-Item -LiteralPath (Join-Path $DependencyRoot 'te_json-src/LICENSE.MIT') -Destination (Join-Path $destination 'licenses/json-LICENSE.MIT')
Copy-Item -LiteralPath (Join-Path $DependencyRoot 'te_clipper2-src/LICENSE') -Destination (Join-Path $destination 'licenses/Clipper2-LICENSE.txt')
$inputs=@('browser/fast/bridge.cpp','browser/fast/CMakeLists.txt','src/cpp/fast.cpp','src/cpp/fast.hpp','src/cpp/io.cpp','src/cpp/geometry.cpp','include/time_estimator/time_estimator.hpp','third_party/manifest.json')
$sources=[ordered]@{}
foreach($inputFile in $inputs) {$sources[$inputFile]=(Get-FileHash -LiteralPath (Join-Path $taskRoot $inputFile) -Algorithm SHA256).Hash.ToLowerInvariant()}
$manifest=[ordered]@{schemaVersion=1;emscripten='6.0.13';clipper2='1.5.4';json='3.12.0';algorithm='src/cpp/fast.cpp';moduleSha256=(Get-FileHash (Join-Path $destination 'fast-estimator.mjs') -Algorithm SHA256).Hash.ToLowerInvariant();sources=$sources}
[IO.File]::WriteAllText((Join-Path $destination 'build.json'),($manifest|ConvertTo-Json -Depth 4)+"`n",[Text.UTF8Encoding]::new($false))
