#!/usr/bin/env bash
# Build tooling only; browser/runtime consumers do not need Bash or Python.
set -euo pipefail
project=$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)
build_root=${1:-"${XDG_CACHE_HOME:-$HOME/.cache}/time-estimator-browser-shapes"}
destination=${2:-"$project/browser/shapes/runtime"}
mkdir -p "$build_root" "$destination"
build_root=$(cd "$build_root" && pwd)
[[ "$build_root" != / && "$build_root" != "$HOME" && "$build_root" != "$project" ]]
port="$build_root/port"
port_revision=873ad293b5efbedd78de7ae6cda8d40c76d958e6
orca_revision=8500fcdccaa10b5099ac20d252af3a7c560046f1
if [[ ! -d "$port/.git" ]]; then
  git clone --filter=blob:none --no-checkout https://github.com/JoshTheDerf/orcaslicer-wasm.git "$port"
  git -C "$port" checkout "$port_revision"
fi
[[ $(git -C "$port" rev-parse HEAD) == "$port_revision" ]]
if [[ ! -d "$port/orca/.git" ]]; then
  git init "$port/orca"
  git -C "$port/orca" remote add origin https://github.com/OrcaSlicer/OrcaSlicer.git
  git -C "$port/orca" fetch --depth=1 --filter=blob:none origin "$orca_revision"
  git -C "$port/orca" sparse-checkout init --cone
  git -C "$port/orca" sparse-checkout set src deps_src cmake resources/info resources/flush localization
  git -C "$port/orca" checkout --detach FETCH_HEAD
fi
[[ $(git -C "$port/orca" rev-parse HEAD) == "$orca_revision" ]]
apply_once() {
  if ! git -C "$1" apply --reverse --check "$2" >/dev/null 2>&1; then
    git -C "$1" apply --check "$2"
    git -C "$1" apply "$2"
  fi
}
apply_once "$port/orca" "$project/browser/shapes/orca-wasm-shapes.patch"
apply_once "$port" "$project/browser/shapes/bridge-shapes.patch"
cp "$project/browser/shapes/ShapePreview.hpp" "$port/orca/src/libslic3r/"
cp "$project/browser/shapes/ShapePreview.hpp" "$project/browser/shapes/timing.hpp" "$project/browser/shapes/timing.cpp" "$port/bridge/"
mkdir -p "$port/time-estimator/src" "$port/time-estimator/include" "$port/time-estimator/deps"
cp "$project/src/cpp/"*.hpp "$port/time-estimator/src/"
cp "$project/src/cpp/fast.cpp" "$project/src/cpp/io.cpp" "$project/src/cpp/geometry.cpp" "$port/time-estimator/src/"
cp -r "$project/include/time_estimator" "$port/time-estimator/include/"
for pair in 'te_clipper2-src clipper' 'te_miniz-src miniz' 'te_pugixml-src pugixml'; do
  read -r from to <<< "$pair"
  mkdir -p "$port/time-estimator/deps/$to"
  tar -C "$project/build/native/_deps/$from" --exclude=.git -cf - . | tar -C "$port/time-estimator/deps/$to" -xf -
done
mkdir -p "$port/time-estimator/deps/generated"
cp "$project/build/native/generated/miniz/"* "$port/time-estimator/deps/generated/"
cd "$port"
export NPROC=${NPROC:-8}
if [[ ! -d toolchain/emsdk/.git ]]; then git clone --filter=blob:none --no-checkout https://github.com/emscripten-core/emsdk.git toolchain/emsdk; fi
git -C toolchain/emsdk fetch origin d7b4130688bfa348392b921ab04015aa15c4f154
git -C toolchain/emsdk checkout d7b4130688bfa348392b921ab04015aa15c4f154
# GCC 15 defaults to C23; the pinned build-only m4 1.4.19 requires C11.
EMSDK_VERSION=6.0.10 CFLAGS='-O2 -std=gnu11' bash toolchain/bootstrap.sh
bash toolchain/build-deps.sh all
source toolchain/env.sh
emcmake cmake -S wasm -B build-wasm -G Ninja -DCMAKE_BUILD_TYPE=Release -DBUILD_VARIANT=release -DORCA_WASM_THREADS=OFF
cmake --build build-wasm --target slicer -j"$NPROC"
cp build-wasm/slicer.mjs build-wasm/slicer.wasm build-wasm/slicer.data "$destination/"
node "$project/browser/scripts/record-shape-runtime.mjs" "$port" "$destination"
