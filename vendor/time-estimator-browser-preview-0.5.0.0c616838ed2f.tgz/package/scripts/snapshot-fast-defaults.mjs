import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
const root = pathToFileURL(resolve(process.argv[2] ?? '') + '/');
if (!process.argv[2]) throw new Error('Supply the checksummed runtime directory');
const lock = JSON.parse(await readFile(new URL('../runtime.lock.json', import.meta.url)));
for (const key of ['module', 'wasm', 'data']) {
  const bytes = await readFile(new URL(lock[key].file, root));
  if (createHash('sha256').update(bytes).digest('hex') !== lock[key].sha256)
    throw new Error('Runtime checksum mismatch: ' + key);
}
const factory = (await import(new URL(lock.module.file, root))).default;
const module = await factory({
  wasmBinary: await readFile(new URL(lock.wasm.file, root)),
  locateFile: (p) => fileURLToPath(new URL(p, root)),
  print() {},
  printErr() {},
});
const out = module._malloc(8);
try {
  if (module._cs_describe_config(out, out + 4) !== 0) throw new Error('Cannot describe runtime defaults');
  const [pointer, length] = new Uint32Array(module.HEAPU8.buffer, out, 2);
  try {
    const schema = JSON.parse(new TextDecoder().decode(module.HEAPU8.subarray(pointer, pointer + length)));
    const numericArrays = ['floats', 'ints', 'percents', 'floatsOrPercents', 'bools'];
    const configuration = Object.fromEntries(
      Object.entries(schema.options).map(([key, value]) => [
        key,
        numericArrays.includes(value.type) ? value.default.split(',') : value.default,
      ]),
    );
    await writeFile(
      new URL('../fast/orca-defaults.mjs', import.meta.url),
      'export default ' +
        JSON.stringify({ engine: lock.engine, runtimeSha256: lock.wasm.sha256, configuration }, null, 2) +
        '\n',
    );
  } finally {
    module._cs_free(pointer);
  }
} finally {
  module._free(out);
}
