import type { Group, BufferGeometry } from 'three';
import type { SupportPreview, FastSupportPreview } from './index.js';
export interface SupportShapeOverlay {
  group: Group;
  setHeight(printZ?: number): void;
  setLayerRange(minZ?: number, maxZ?: number): void;
  setVisible(visible: boolean): void;
  dispose(): void;
}
export function createSupportShapeOverlay(preview: FastSupportPreview, options?: {color?: string; maxVertices?: number}): SupportShapeOverlay;
export interface SupportOverlay {
  group: Group;
  setHeight(printZ?: number): void;
  setLayerRange(minZ?: number, maxZ?: number): void;
  setMoveRange(start?: number, end?: number): void;
  setEndMove(end?: number): void;
  setFeatureVisible(role: number, visible: boolean): void;
  setVisible(visible: boolean): void;
  dispose(): void;
}
export function createSupportOverlay(preview: SupportPreview, options?: { baseColor?: string; interfaceColor?: string; chunkSegments?: number }): SupportOverlay;
export function createToolpathOverlay(preview: SupportPreview, options?: { chunkSegments?: number }): SupportOverlay;
export function createPlacementHull(positions: Float32Array): BufferGeometry;
