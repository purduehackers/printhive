#include "fast.hpp"
#include <algorithm>
#include <cmath>
#include <limits>

// This boundary reuses the native sampled-section algorithm, not the server SDK or runtime adapter.
extern "C" const char *te_fast_run(const float *vertices, unsigned vertex_count,
                                  const unsigned *indices, unsigned triangle_count,
                                  const double *transform, const char *settings, unsigned settings_size) {
    static std::string output;
    using namespace te;
    try {
        const auto started = Clock::now();
        FastBudget budget{started, 10};
        if (!vertices || !indices || !transform || vertex_count < 3 || triangle_count == 0)
            throw Error("invalid_mesh", "Fast preview needs a complete indexed mesh");
        auto scene = std::make_shared<Scene>();
        scene->parts.emplace_back();
        auto &part = scene->parts.front();
        for (unsigned i = 0; i < vertex_count; ++i)
            part.vertices.push_back({vertices[i * 3], vertices[i * 3 + 1], vertices[i * 3 + 2]});
        Matrix matrix{};
        for (unsigned row = 0; row < 4; ++row)
            for (unsigned col = 0; col < 4; ++col)
                matrix[row][col] = transform[col * 4 + row];
        Bounds bounds{{INFINITY, INFINITY, INFINITY}, {-INFINITY, -INFINITY, -INFINITY}};
        for (unsigned i = 0; i < triangle_count; ++i) {
            const std::array<unsigned, 3> face{indices[i * 3], indices[i * 3 + 1], indices[i * 3 + 2]};
            for (unsigned index : face) {
                if (index >= vertex_count) throw Error("invalid_mesh", "Triangle index out of range");
                const auto point = te::apply(matrix, part.vertices[index]);
                for (unsigned axis = 0; axis < 3; ++axis) {
                    if (!std::isfinite(point[axis])) throw Error("invalid_mesh", "Nonfinite mesh coordinate");
                    bounds.low[axis] = std::min(bounds.low[axis], point[axis]);
                    bounds.high[axis] = std::max(bounds.high[axis], point[axis]);
                }
            }
            part.triangles.push_back(face);
        }
        Profiles profiles;
        const auto config = Json::parse(settings, settings + settings_size);
        profiles.printer = profiles.process = config;
        profiles.filaments = Json::array({{{"profile", config}}});
        fast_validate(profiles);
        Instance instance{"model", "browser-mesh", scene, matrix, bounds, 1};
        const auto spec = fast_section_spec(instance, profiles);
        const auto features = fast_extract(instance, spec, budget);
        const auto result = fast_predict(features, instance, profiles, budget);
        output = Json{{"ok", true}, {"result", result}, {"computeMilliseconds", seconds_since(started) * 1000}}.dump();
    } catch (const Error &error) {
        output = Json{{"ok", false}, {"error", error.json()}}.dump();
    } catch (const std::exception &error) {
        output = Json{{"ok", false}, {"error", {{"code", "fast_failed"}, {"message", error.what()}}}}.dump();
    }
    return output.c_str();
}
