# Browser fast time kernel

This separate C++17/Emscripten target compiles the existing native `src/cpp/fast.cpp`
sampled-section and motion/cooling proxy, with pinned Clipper2 1.5.4 and JSON 3.12.0.
The unchanged io/geometry translation units provide shared utilities; unused filesystem,
archive, server/runtime and forecasting code is removed by function-section linking.
No native/server estimator library, process or service is linked or called.

`../fast.mjs` validates and places complete indexed geometry, including explicit units and
orientation, then passes binary mesh buffers and effective settings through a narrow ABI.
The result is an **experimental model-body estimate**. It excludes supports, startup and
finish operations. Unsupported features/open sections fail; no full slicing is hidden inside
this path. It creates no printable toolpaths. Native geometry limitations still apply.

`orca-defaults.mjs` records serialized defaults from the checksum-pinned Orca ABI-1
`cs_describe_config` export. Request overrides are merged with these defaults, rather than
using handpicked nominal speeds. Disabled `disabled_fuzzy` maps to the native estimator's
equivalent legacy `none` spelling. Default identity is tied to the engine binary hash,
whose exact source equivalence remains unknown. Profile inheritance must already be resolved.
Refresh the snapshot with `node browser/scripts/snapshot-fast-defaults.mjs RUNTIME_DIRECTORY`;
the tool verifies the locked engine assets before reading their defaults.

Build from the full source checkout using Emscripten 6.0.13, CMake, Ninja and the pinned
dependency sources populated by the normal CMake configure:

```powershell
browser/scripts/build-fast.ps1 -EmsdkRoot PATH
```

`-DependencyRoot` can select that dependency source cache. `build.json` records the output
and shared source hashes; original native source files are not modified by this browser build.
Clipper2/JSON notices are in `licenses/`; the Emscripten runtime notices are retained in
the package's `repair/licenses/`. Newly authored project code remains private/unpublished.

One local Chromium development-session check (25 October 2026, illustrative 0.4 mm PLA,
0.2 mm layers, 15% infill, Core ONE bed) measured input-to-time display as 0.43 s on the box
fixture and 0.97 s on a supplied 688-triangle case after choosing meters. Opening full tree
Layers then took 0.89 s and 6.95 s respectively. Both quick requests made zero full-engine
requests. These are two observations on a warmed development server, not general latency or
accuracy guarantees. The quick values exclude supports; the full values include them.
