import { requireValue, limitsFor } from './errors.mjs';

/** Validate pre-toolpath support regions. Coordinates are canonical Z-up millimeters. */
export function readSupportShapes(payload, options) {
  const limits = limitsFor(options);
  requireValue(payload?.schemaVersion === 1 && Array.isArray(payload.layers), 'invalid_runtime_output', 'Invalid support shapes');
  requireValue(payload.layers.length <= 100000, 'shape_limit', 'Too many support layers');
  let vertexCount = 0;
  const ring = (points) => {
    requireValue(Array.isArray(points) && points.length >= 3, 'invalid_runtime_output', 'Invalid support outline');
    vertexCount += points.length;
    requireValue(vertexCount <= Math.min(limits.maxSegments, 4000000), 'shape_limit', 'Support shapes exceed the browser budget');
    for (const point of points)
      requireValue(Array.isArray(point) && point.length === 2 && point.every(value => Number.isFinite(value) && Math.abs(value) < 100000),
        'invalid_runtime_output', 'Invalid support coordinate');
    return points;
  };
  const shapes = payload.layers.map(layer => {
    requireValue(Number.isFinite(layer.bottomZ) && Number.isFinite(layer.printZ) && layer.bottomZ >= -0.001 &&
      layer.printZ > layer.bottomZ && layer.printZ <= 100000 && Array.isArray(layer.polygons),
      'invalid_runtime_output', 'Invalid support layer');
    return { bottomZ: layer.bottomZ, printZ: layer.printZ, polygons: layer.polygons.map(polygon => {
      requireValue(Array.isArray(polygon.holes), 'invalid_runtime_output', 'Invalid support holes');
      return { contour: ring(polygon.contour), holes: polygon.holes.map(ring) };
    }) };
  }).sort((a, b) => a.printZ - b.printZ);
  const heights = new Map();
  for (const layer of shapes) heights.set(layer.printZ, layer.printZ - layer.bottomZ);
  return { shapes, vertexCount, layers: [...heights].map(([printZ, height]) => ({ printZ, height })) };
}
