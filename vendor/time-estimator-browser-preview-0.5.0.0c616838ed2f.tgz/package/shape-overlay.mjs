import * as THREE from 'three';
import { requireValue } from './errors.mjs';

/** Batched solid support regions, without printable lines or feature classifications. */
export function createSupportShapeOverlay(preview, { color = '#52b788', maxVertices = 12000000 } = {}) {
  requireValue(preview?.representation === 'support_shapes', 'invalid_request', 'Expected support shapes');
  const group = new THREE.Group();
  const material = new THREE.MeshStandardMaterial({ color, roughness: 0.8, side: THREE.FrontSide });
  const chunks = [];
  let buffer = new Float32Array(262134), used = 0, total = 0, ranges = [];
  const flush = () => {
    if (!used) return;
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(buffer.slice(0, used), 3));
    geometry.computeVertexNormals();
    const mesh = new THREE.Mesh(geometry, material);
    group.add(mesh);
    chunks.push({ geometry, ranges });
    used = 0;
    ranges = [];
  };
  let topZ = 0;
  const triangle = (a, b, c) => {
    requireValue(total + 3 <= maxVertices, 'shape_limit', 'Support view exceeds the browser drawing budget');
    if (used + 9 > buffer.length) flush();
    if (!ranges.length || ranges.at(-1).topZ !== topZ) ranges.push({ topZ, start: used / 3, end: used / 3 });
    buffer.set([...a, ...b, ...c], used);
    used += 9;
    total += 3;
    ranges.at(-1).end = used / 3;
  };
  try {
    for (const layer of preview.shapes) {
      topZ = layer.printZ;
      for (const polygon of layer.polygons) {
        const contour = polygon.contour.map(point => new THREE.Vector2(...point));
        const holes = polygon.holes.map(ring => ring.map(point => new THREE.Vector2(...point)));
        if (THREE.ShapeUtils.isClockWise(contour)) contour.reverse();
        for (const hole of holes) if (!THREE.ShapeUtils.isClockWise(hole)) hole.reverse();
        const points = [...contour, ...holes.flat()];
        for (let [a, b, c] of THREE.ShapeUtils.triangulateShape(contour, holes)) {
          const pa = points[a], pb = points[b], pc = points[c];
          if ((pb.x - pa.x) * (pc.y - pa.y) - (pb.y - pa.y) * (pc.x - pa.x) < 0) [b, c] = [c, b];
          const vertex = (index, z) => [points[index].x, points[index].y, z];
          triangle(vertex(a, topZ), vertex(b, topZ), vertex(c, topZ));
          triangle(vertex(c, layer.bottomZ), vertex(b, layer.bottomZ), vertex(a, layer.bottomZ));
        }
        for (const ring of [contour, ...holes])
          for (let i = 0; i < ring.length; i++) {
            const a = ring[i], b = ring[(i + 1) % ring.length];
            const a0 = [a.x, a.y, layer.bottomZ], a1 = [a.x, a.y, topZ];
            const b0 = [b.x, b.y, layer.bottomZ], b1 = [b.x, b.y, topZ];
            triangle(a0, b0, b1);
            triangle(a0, b1, a1);
          }
      }
    }
    flush();
  } catch (error) {
    for (const chunk of chunks) chunk.geometry.dispose();
    material.dispose();
    throw error;
  }
  buffer = null;
  const setLayerRange = (minZ = -Infinity, maxZ = Infinity) => {
    for (const chunk of chunks) {
      const visible = chunk.ranges.filter(range => range.topZ >= minZ - 1e-6 && range.topZ <= maxZ + 1e-6);
      const start = visible[0]?.start ?? 0, end = visible.at(-1)?.end ?? start;
      chunk.geometry.setDrawRange(start, end - start);
    }
  };
  return {
    group,
    setLayerRange,
    setHeight(printZ = Infinity) { setLayerRange(-Infinity, printZ); },
    setVisible(visible) { group.visible = visible; },
    dispose() {
      group.removeFromParent();
      for (const chunk of chunks) chunk.geometry.dispose();
      material.dispose();
    },
  };
}
