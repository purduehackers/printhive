import createKernel from './fast/fast-estimator.mjs';
import defaults from './fast/orca-defaults.mjs';
import { prepareMesh, bedCenterFor } from './geometry.mjs';
import { PreviewError, requireValue } from './errors.mjs';

/** Explicit model-body preview. No native slicer, supports, startup or finish operations are run. */
export async function estimateFast(request, mesh) {
  requireValue(
    request.scope === 'model_body',
    'invalid_request',
    'Choose the model_body scope for a quick estimate',
  );
  requireValue(
    request.profile?.configuration && !('inherits' in request.profile.configuration),
    'needs_configuration',
    'Supply resolved preview settings',
  );
  const started = performance.now();
  const config = { ...defaults.configuration, ...request.profile.configuration };
  if (request.layerHeight !== undefined) config.layer_height = String(request.layerHeight);
  if (request.infill !== undefined) config.sparse_infill_density = `${request.infill}%`;
  // The caller explicitly requested a body-only prediction. Retain fast_validate for other exclusions.
  config.enable_support = '0';
  if (config.fuzzy_skin === 'disabled_fuzzy') config.fuzzy_skin = 'none';
  const prepared = prepareMesh(mesh, {
    rotation: request.rotation,
    mirrorX: request.mirrorX ?? false,
    scale: request.scale,
    bedCenter: bedCenterFor(config),
    limits: request.limits,
  });
  const kernel = await createKernel({ print() {}, printErr() {} });
  const pointers = [];
  const copy = (bytes) => {
    const pointer = kernel._malloc(bytes.byteLength);
    requireValue(pointer, 'out_of_memory', 'Not enough memory for a quick estimate');
    pointers.push(pointer);
    kernel.HEAPU8.set(bytes, pointer);
    return pointer;
  };
  try {
    const positions = copy(
      new Uint8Array(prepared.positions.buffer, prepared.positions.byteOffset, prepared.positions.byteLength),
    );
    const indices = copy(
      new Uint8Array(prepared.indices.buffer, prepared.indices.byteOffset, prepared.indices.byteLength),
    );
    const transform = copy(new Uint8Array(new Float64Array(prepared.sourceToPlate).buffer));
    const settings = new TextEncoder().encode(JSON.stringify(config));
    const settingsPointer = copy(settings);
    const pointer = kernel._te_fast_run(
      positions,
      prepared.positions.length / 3,
      indices,
      prepared.indices.length / 3,
      transform,
      settingsPointer,
      settings.length,
    );
    const report = JSON.parse(kernel.UTF8ToString(pointer));
    if (!report.ok) throw new PreviewError(report.error.code, report.error.message, report.error.details);
    return {
      schemaVersion: 1,
      bodySeconds: report.result.body_seconds,
      scope: 'model_body',
      basis: 'fast_sampled_body_proxy',
      excludes: ['supports', 'startup', 'finish'],
      samples: report.result.sample_count,
      layers: report.result.layer_count,
      bounds: prepared.bounds,
      sourceToPlate: prepared.sourceToPlate,
      computeMilliseconds: performance.now() - started,
      nativeComputeMilliseconds: report.computeMilliseconds,
      physicalCalibration: false,
      defaultsRuntimeSha256: defaults.runtimeSha256,
    };
  } finally {
    for (const pointer of pointers) kernel._free(pointer);
  }
}
