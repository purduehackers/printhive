import type { Mesh, PreviewRequest, FastPreview } from './index.js';
export function estimateFast(request: PreviewRequest & {scope:'model_body'}, mesh:Mesh):Promise<FastPreview>;
