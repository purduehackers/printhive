# Standalone browser print preview

An independently packaged browser library for fast FDM print estimates and solid generated support
inspection. One worker task prepares the model once for support shapes and a time estimate
including supports. It optionally adds a batched Three.js overlay to an existing scene. It contains no React, PrintHive, database,
native executable, server SDK, or Node worker dependency. Its optional STL importer reuses
Orca's C++ repair sequence in a small, bundled WebAssembly module. The core entry does not import Three.js.

This package is private pending a project distribution license. Local integration is supported;
it has not been published. See [NOTICE.md](NOTICE.md).

## Use with your own viewer

```js
import { createPreviewClient } from '@time-estimator/browser-preview';
import { createSupportShapeOverlay } from '@time-estimator/browser-preview/three';
const client = createPreviewClient({ manifestUrl: '/preview-engine/manifest.json' });
const result = await client.estimate({
  input: { positions, indices }, // complete Float32 XYZ and optional Uint32 triangle indices
  profile: { id: 'my-profile-revision', label: 'My printer / process / filament', configuration },
  support: 'tree', scope: 'model_and_supports', mirrorX: false,
}, { onProgress: progress => console.log(progress.stage) });
const overlay = createSupportShapeOverlay(result);
scene.add(overlay.group); // canonical Z-up millimeters, shared with the model
console.log(result.estimatedSeconds);
overlay.setHeight(result.layers.at(-1)?.printZ);
// Later: overlay.dispose(); client.dispose();
```

Supply an explicitly selected effective Orca configuration. Preset inheritance is not resolved in
JavaScript: unresolved inheritance is rejected. Orca initializes its full C++ defaults and applies
the supplied configuration; describe a defaults-plus-overrides scenario honestly in profile.basis.
The caller owns profile selection and versioning. Profile substitutions/unknown settings fail.
Request layerHeight and infill, when supplied, are declared process overrides. The support type
is explicitly selected; remaining style/gap/interface/bed policies come from the profile.

Only the default support style, rectangular beds, one full mesh/one material and planar printed paths are admitted by this
adapter. Input positions are millimeters, Z-up. The part is centered on the selected bed and its
bottom grounded. The returned column-major sourceToPlate matrix describes the placement.
Mirroring is an explicit X reflection around the source bounding-box center; triangle winding is
corrected before generation. Supports are regenerated after pose/configuration changes.

Do not supply a sampled display mesh. The default Worker accepts an already decoded mesh.
Unindexed triangles are joined at exactly equal vertex coordinates, restoring STL connectivity
without moving vertices. Caller-supplied indexed meshes must already describe their shared topology.
For STL, use `readSTL(file, {limits})` from `/stl` in a custom Worker. It runs the same C++
repair sequence as Orca's STL import, including nearby-edge and normal correction, without
hole filling. PrintHive uses this importer for slicing and automatic orientation. Its model
display and submission transformation retain the original file's complete geometry. STEP
conversion remains caller-owned.

```js
import { installSupportWorker } from '@time-estimator/browser-preview/worker';
import { readSTL } from '@time-estimator/browser-preview/stl';
installSupportWorker({ decodeMesh: (file, limits) => readSTL(file, { limits }) });
```

## Orientation and submitted geometry

`client.orient({input, rotation, mirrorX})` calls Orca's AutoOrienter. It returns an absolute
row-major 3x3 `rotation`, which can be passed unchanged to `generate`. Mirroring is applied in
source X before rotation. Auto orientation uses a centered copy, avoiding large source offsets.
`rotationForFace(normal)` and `multiplyRotations(delta,current)` from `/pose` implement manual
lay-on-face placement. A selected outward normal is aligned to -Z; `/three` exports
`createPlacementHull` for selectable outer placement faces rather than concave/internal triangles.

`prepareMesh` returns the canonical column-major `sourceToPlate` placement. The selected pose,
display bounds and native paths all share this transform; changed poses regenerate the slice.
`createSTLWriter(triangleCount,transform)` incrementally writes every original triangle to binary
STL, recalculating normals and reversing mirrored winding. Feed it original-winding triangles,
not the already reversed native indices from a mirrored `prepareMesh` result. The host owns when
to save or submit that new Blob. PrintHive serializes each batch file independently before
reserving its upload, sends the transformed byte count and clears the already baked mirror
instruction. Original source files remain available for reset/reselection.

`fitBed: true` explicitly expands a virtual preview bed when needed, without scaling geometry.
This is useful for illustrative viewers; physical printer-fit checks must use actual fleet
dimensions. The default preserves the caller's declared bed.

## Display contract

Result schema 1 contains Float64 segments with stride 9:
`x0,y0,z0,x1,y1,z1,width,height,role`. All dimensions are millimeters in canonical plate space.
`view: 'print'` returns model and support extrusions, including walls, infill, surfaces, bridges
and helpers. `features` identifies each used role with its Orca 2.4.2 label and default color.
Print layers contain actual print Z, height, and the zero-based `[startSegment,endSegment)`
interval in original G-code order. Supports set to `none` still generate the model's print paths.
The default `view: 'supports'` preserves support-only output (role 1 base, role 2 interface/contact, role 17 transition),
including empty ready output versus disabled supports. Support-only layer heights can differ
from the object's layers. Generation keys cover the view, geometry, mirrored topology, pose, effective settings,
profile/runtime/extractor identities. These identities are separate from native .tecache states.

`createToolpathOverlay` uses Orca's feature palette; `createSupportOverlay` retains the original
two-color support-only adapter. Both use beveled, pointed beads with occupied Z interval printZ-height..printZ.
This is an approximation of the appearance of the generated extrusion, not a printable solid or
a physical support-strength simulation. Instanced endpoints/width/height replace per-segment
expanded box geometry. Beveled sections avoid coincident flat top surfaces; explicit smoothly
interpolated radial normals avoid noisy screen-space derivatives on very small triangles.
Compatible consecutive lines share bounded miters, including closed-loop seams, so their
end caps do not overlap at every short segment. Feature/dimension changes break a join;
near reversals retain individual caps. This affects presentation only, not native paths or time.
When layers are smaller than a screen pixel, their lighting detail is filtered to avoid shimmer;
zooming in restores the individual bead highlights without dropping extrusion geometry.
Groups/chunks reduce draw calls; resources are explicitly
disposed. `setLayerRange(minZ,maxZ)` clips to a layer or stack; `setEndMove(exclusiveIndex)`
reveals extrusion order across feature batches without rebuilding geometry. `setMoveRange(start,end)`
selects exactly the current layer's paths, including differing support/model bead heights. `setFeatureVisible`
toggles a role. Playback speed is owned by the host; segment progression is not physical timing.
Parent transforms are respected when clipping. `displayTransform(bounds)` provides
the normalized, Y-up camera presentation used by PrintHive; apply the same matrix to both model
and supports. Do not normalize supports independently or apply mirroring twice.
The instanced path meshes are for rendering; stock Three.js CPU raycasting does not resolve
individual deformed extrusion instances. Placement-face picking uses ordinary hull geometry.

The appearance follows [Orca's pinned libvgcode segment representation](https://github.com/OrcaSlicer/OrcaSlicer/blob/8500fcdccaa10b5099ac20d252af3a7c560046f1/src/libvgcode/src/SegmentTemplate.cpp)
and the feature legend/layer/progress arrangement in the [Prusa G-code viewer reference](https://help.prusa3d.com/article/prusaslicer-g-code-viewer_193152).
The host retains its own branding and control layout.

Generated G-code from Orca ABI 1 is decoded only for presentation. The reader tracks Cartesian
absolute/relative moves, extrusion modes/reset, dimensions, native feature roles and XY I/J arcs. Arc
display chords have <=0.02 mm sagitta and <=1 mm length. Unsupported inch/workspace/G92 XYZ,
nonplanar extrusion or missing dimensions fails rather than inventing geometry. No
time estimate is calculated from these paths. Time/material statistics come from Orca's C++
GCodeProcessor; returned time is an uncalibrated slicer reference with no physical upper bound.
## Combined fast preview

`client.estimate({...request, scope: 'model_and_supports'})` is the default fast operation.
Orca prepares physical model sections and generates normal/tree support regions once.
The existing C++ fast predictor reuses these sections and prices the support regions,
including internal contact/interface work, with shared cooling. It skips support extrusion
lines and G-code export. The viewer receives solid shapes with holes and physical heights.

```js
import { createSupportShapeOverlay } from '@time-estimator/browser-preview/three';
const quick = await client.estimate({
  input: mesh, profile, support: 'tree', scope: 'model_and_supports',
});
console.log(quick.estimatedSeconds); // approximate model + supports; excludes startup/finish
const overlay = createSupportShapeOverlay(quick);
scene.add(overlay.group);
overlay.setHeight(quick.layers.at(-1)?.printZ);
```

This is an experimental printing-body estimate, with no physical calibration or deadline
bound. Support regions come from Orca; their printing time is a region-based approximation,
not full motion simulation. Full `generate` remains an explicit optional toolpath operation;
PrintHive's fast preview does not call it. See [shared preparation, pricing and build](shapes/README.md).

Consumers needing timing without support inspection can explicitly request
`scope:'model_body'`. That legacy operation uses the smaller sampled C++ kernel and returns
`bodySeconds`, excluding supports as well as startup/finish. Label it **model only**.
It can reject open sections the Orca-based combined operation accepts. See [small kernel](fast/README.md).

`scale` is an explicit positive uniform multiplier shared by timing, native orientation,
`generate`, and `poseMatrix(rotation,mirror,scale)`. STL is unitless: the default is one
millimeter per coordinate. A host can offer meters (`1000`) or inches (`25.4`) and bake that
choice into submitted STL using the same complete geometry writer. Tiny meshes must never
be silently enlarged. Changing units invalidates every geometry-dependent preview.

## Runtime and lifecycle

Copy the separately built, bundled serial runtime to the host's static asset directory:

```sh
node node_modules/@time-estimator/browser-preview/scripts/fetch-runtime.mjs public/preview-engine --replace
```

The provisioning tool verifies the fixed SHA-256 lock. Updating existing assets requires
`--replace`; the default refuses mismatches.
It supports Node or Bun and requires no native estimator installation. Serve the resulting public
assets from the same origin with the manifest. The browser independently verifies all asset
hashes before importing glue and instantiating WASM, and checks the engine version/ABI. The
lock records the source-built Orca/bridge revisions and support-shape extension. This does
not establish universal desktop parity. A host can supply another compatible checksummed manifest explicitly.

Only requested engine files are fetched; input geometry is never uploaded by this package.
The serial engine needs no cross-origin isolation. Blob module imports must be allowed by the
host's content policy. SHA-256 uses Web Crypto when available and a bundled, pinned JavaScript
fallback on ordinary HTTP development origins where `crypto.subtle` is unavailable. Engine integrity
checks are identical on both paths. Use HTTPS for deployed sites; the fallback does not secure HTTP transport.
Initialization and slicing
share the request deadline. Cancel/replacement/disposal terminates the dedicated Worker and its
heap; synchronous C++ work does not need to service a cancellation message. No mutable worker or computed-model cache
survives a completed request. Browser HTTP/WASM caches can retain engine assets. Mutable job/profile scheduling remains caller-owned.

Default admission: 10 million triangles, 8 million displayed extrusion segments (support-region vertices are additionally capped at 4 million), 512 MiB generated output and
5 minutes. PrintHive accepts files up to its 500 MiB submission limit. These are limits, not device guarantees.
The STL importer has its own bounded WASM heap; call it inside the disposable request worker.
A WASM memory limit does not include GPU,
transport or viewer buffers; hosts should narrow admission for their tested devices. Runtime traps,
download/integrity failures, unsupported output, allocation limits and deadlines are structured
PreviewErrors. A failed preview must not disable the host's file submission.

## Development and validation

```sh
bun install --frozen-lockfile
bun run test
bun run check
# Fetch runtime first; PREVIEW_RUNTIME can select its directory.
bun run test:runtime
bun run test:browser
```

Tests cover transforms/mirroring, modal path extraction and arcs, feature/layer intervals, budgets,
ordered playback across render chunks, clipping/resource disposal, worker cancellation, full print
paths with supports disabled, solid support holes/heights, combined timing and synthetic tree generation when the runtime is
provisioned. Browser tests exercise the actual default Worker, integrity loader, WASM and renderer.
Import tests cover broken normals/winding and exact shared topology; runtime tests include curved
output beyond the old 250,000-segment cap, regular supports, virtual beds and native orientation.
Desktop Orca and a browser still have different memory ceilings; this release does not claim
universal desktop parity or qualification of every engine setting and model. Physical timing,
mobile limits and broad real-model performance remain separate validation.

The root CMake build, native SDK installation/source archive and bindings/typescript package do
not depend on or package this browser library. Pack this directory separately for a consumer;
Three.js is optional unless that consumer imports the `/three` entry.
