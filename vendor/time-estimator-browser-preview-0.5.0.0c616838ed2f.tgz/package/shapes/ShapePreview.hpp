#pragma once

#include "libslic3r/ExPolygon.hpp"
#include <functional>

namespace Slic3r {
class PrintObject;
struct SupportShapeStyle {
    double width;
    double density;
    double speed;
    int walls;
    bool interface;
};
struct CapturedSupportShape {
    const PrintObject *object;
    double bottom_z;
    double print_z;
    ExPolygons polygons;
    SupportShapeStyle style;
};

// Scoped to one serial browser request. Production slicing leaves this null.
struct SupportShapePreview {
    bool reduced_pipeline = true;
    std::function<void(const PrintObject &, double, double, const ExPolygons &, const SupportShapeStyle &)> capture;
};
inline thread_local SupportShapePreview *support_shape_preview = nullptr;
}
