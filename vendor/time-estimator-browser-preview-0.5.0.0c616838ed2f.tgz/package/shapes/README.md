# Combined fast estimate and support shapes

The browser engine prepares the model once for two outputs: solid generated support
regions for viewing and an experimental print-body estimate that includes those supports.
This component is built independently of the server SDK. Server slicing/cache integration
is deferred.

## Pipeline and coordinates

The pinned Orca 2.4.2 source prepares physical layers, model perimeters and bridge/contact
surfaces. Its normal/tree support generator creates support regions. A scoped browser-only
hook captures these polygons before support extrusion generation. Ordinary full slicing
leaves the hook null. The reduced pipeline omits model infill paths except where regular
support layer planning reads bridging fills, and omits support toolpaths and G-code export.

Support polygons include holes and their physical bottom/top Z in millimeters. Internal
contact/interface classifications still influence placement and time, but the viewer
renders a single solid support color. The source-to-plate transform is shared with model
placement, units, mirroring and export. Neither display sampling nor the timing strata
determine support geometry.

Timing reuses physical model slices already needed for supports. Up to 48 model strata
feed the existing C++ fast predictor; all captured support regions contribute printing
cost using their native flow width, spacing/density, speeds and wall policy. Model and
support costs share cooling evaluation. It does not add an independently cooled model
estimate to a separate support duration. Support line lengths and motion are proxies,
not generated printer paths. Startup/finish operations and physical calibration remain
outside this estimate.

## Browser contract

`client.estimate({input, profile, support, scope:'model_and_supports'})` returns
`FastSupportPreview`: `estimatedSeconds`, diagnostic `supportSeconds`, `shapes`,
`layers`, `bounds`, `sourceToPlate` and engine/settings provenance. This is the default
estimate scope; the explicit legacy `model_body` scope remains available for consumers
that need a smaller kernel without support inspection. PrintHive uses one combined task.
The Three.js `createSupportShapeOverlay` helper displays regions with a height slider.

Changing settings, units or pose cancels the old worker, including its WASM heap. Results
must remain bound to the active file/settings revision. A valid empty support result is
different from failed generation. The estimate remains approximate even if the support
regions match Orca's intermediate output.

## Build and qualification

The source-built serial engine extends the existing Cubby bridge at
`873ad293b5efbedd78de7ae6cda8d40c76d958e6` and Orca at
`8500fcdccaa10b5099ac20d252af3a7c560046f1`. The build uses source patches plus the
authored capture/timing adapter in this directory. No server estimator executable,
service or static SDK library is required by the browser.

Build provenance, retained third-party notices and the runtime checksums accompany the
compiled module. The [qualification checks](../tests/README.md) cover synthetic and supplied-file regions,
combined pricing, ordinary HTTP and rendering. Default normal
and tree styles are the target. Orca maps its default tree style to the organic pipeline;
the adapter captures that pipeline separately from the older tree generator. Pre-toolpath regions can differ from the footprint
of final extrusion lines where later clipping/loop processing changes it.

Rebuild from the full estimator checkout after its normal CMake configure has populated
`build/native/_deps` and the generated miniz headers. On Linux run
`bash browser/scripts/build-shapes.sh`; on Windows with Ubuntu/WSL use
`browser/scripts/build-shapes.ps1`. The script uses a separate persistent Linux build
cache, pinned upstream checkouts, CMake and Emscripten 6.0.10. It does not modify the
server runtime. The predictor's Clipper2 1.5.4 symbols and headers are isolated from
Orca's embedded 1.5.2 version. Re-record runtime checksums/notices after rebuilding;
`record-shape-runtime.mjs` verifies authored source copies before recording them.
