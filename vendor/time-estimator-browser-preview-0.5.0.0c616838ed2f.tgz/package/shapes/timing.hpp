#pragma once
#include "ShapePreview.hpp"
#include "fast.hpp"
#include "libslic3r/Print.hpp"
#include "libslic3r/Layer.hpp"

te::Json estimate_shape_time(const Slic3r::Print &print, const Slic3r::DynamicPrintConfig &configuration,
                             const std::vector<Slic3r::CapturedSupportShape> &supports);
