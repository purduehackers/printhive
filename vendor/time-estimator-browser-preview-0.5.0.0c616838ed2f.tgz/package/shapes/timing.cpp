#include "timing.hpp"
#include <algorithm>
#include <cmath>

namespace {
te::Json contours(const Slic3r::ExPolygons &polygons) {
    auto result = te::Json::array();
    const auto ring = [&](const Slic3r::Polygon &polygon) {
        auto points = te::Json::array();
        for (const auto &point : polygon.points)
            points.push_back({std::llround(Slic3r::unscale<double>(point.x()) * 100000.),
                              std::llround(Slic3r::unscale<double>(point.y()) * 100000.)});
        return points;
    };
    for (const auto &polygon : polygons) {
        result.push_back(ring(polygon.contour));
        for (const auto &hole : polygon.holes) result.push_back(ring(hole));
    }
    return result;
}
}

te::Json estimate_shape_time(const Slic3r::Print &print, const Slic3r::DynamicPrintConfig &configuration,
                             const std::vector<Slic3r::CapturedSupportShape> &supports) {
    using namespace te;
    if (print.objects().size() != 1)
        throw Error("unsupported_fast_settings", "Combined fast preview needs one model");
    const auto &object = *print.objects().front();
    const auto &layers = object.layers();
    if (layers.empty()) throw Error("unsupported_fast_geometry", "No physical layers were generated");
    Json config = Json::object();
    for (const auto &key : configuration.keys()) {
        const auto *option = configuration.option(key);
        config[key] = option->is_vector()
            ? Json(static_cast<const Slic3r::ConfigOptionVectorBase *>(option)->vserialize())
            : Json(option->serialize());
    }
    Profiles profiles;
    profiles.printer = profiles.process = config;
    profiles.filaments = Json::array({{{"profile", config}}});
    // Validate the existing body surrogate's scope without suppressing generated support pricing.
    auto validation = profiles;
    validation.process["enable_support"] = "0";
    if (validation.process.value("fuzzy_skin", "") == "disabled_fuzzy")
        validation.process["fuzzy_skin"] = "none";
    fast_validate(validation);
    Instance instance{};
    instance.bounds.low = {0, 0, 0};
    instance.bounds.high = {1, 1, layers.back()->print_z};
    const auto spec = fast_section_spec(instance, profiles);
    const double top_depth = spec.at("top_depth"), bottom_depth = spec.at("bottom_depth");
    const auto at_z = [&](double z) {
        if (z < 0 || z >= layers.back()->print_z) return Json::array();
        const auto it = std::lower_bound(layers.begin(), layers.end(), z,
            [](const Slic3r::Layer *layer, double value) { return layer->print_z < value; });
        return it == layers.end() ? Json::array() : contours((*it)->lslices);
    };
    // Physical support layers are all priced. Model strata reuse slices already
    // computed for support placement; no second mesh intersection pass occurs.
    const size_t count = layers.size(), strata = std::min<size_t>(48, count);
    std::vector<std::pair<size_t, size_t>> ranges;
    if (count <= strata) {
        for (size_t i = 0; i < count; ++i) ranges.emplace_back(i, i + 1);
    } else {
        const double h = spec.at("layer_height");
        const size_t bottom = std::min(strata / 3, std::max<size_t>(1, std::ceil(bottom_depth / h)));
        const size_t top = std::min(strata / 3, std::max<size_t>(1, std::ceil(top_depth / h)));
        for (size_t i = 0; i < bottom; ++i) ranges.emplace_back(i, i + 1);
        const size_t middle = strata - bottom - top;
        for (size_t i = 0; i < middle; ++i)
            ranges.emplace_back(bottom + i * (count - bottom - top) / middle,
                                bottom + (i + 1) * (count - bottom - top) / middle);
        for (size_t i = count - top; i < count; ++i) ranges.emplace_back(i, i + 1);
    }
    auto samples = Json::array();
    std::vector<size_t> layer_to_sample(count);
    for (size_t sample_id = 0; sample_id < ranges.size(); ++sample_id) {
        const auto [begin, end] = ranges[sample_id];
        const size_t index = (begin + end - 1) / 2;
        const auto &layer = *layers[index];
        const double z = layer.slice_z;
        samples.push_back({{"index", index}, {"weight", end - begin}, {"h", layer.height},
            {"contours", contours(layer.lslices)}, {"above", at_z(z + top_depth)},
            {"below", at_z(z - bottom_depth)},
            {"next", index + 1 < count ? contours(layers[index + 1]->lslices) : Json::array()},
            {"support_moves", Json::array()}});
        for (size_t i = begin; i < end; ++i) layer_to_sample[i] = sample_id;
    }
    for (const auto &support : supports) {
        auto it = std::lower_bound(layers.begin(), layers.end(), support.print_z - 1e-6,
            [](const Slic3r::Layer *layer, double value) { return layer->print_z < value; });
        const size_t index = std::min<size_t>(std::distance(layers.begin(), it), count - 1);
        auto &sample = samples[layer_to_sample[index]];
        const auto &style = support.style;
        sample["support_moves"].push_back({{"contours", contours(support.polygons)},
            {"height", support.print_z - support.bottom_z}, {"width", style.width},
            {"density", style.density}, {"walls", style.walls}, {"interface", style.interface},
            {"speed", style.speed}, {"weight", 1. / sample.at("weight").get<double>()}});
    }
    Json features{{"spec", spec}, {"layer_count", count}, {"samples", std::move(samples)}};
    FastBudget budget{Clock::now(), 60};
    auto result = fast_predict(features, instance, profiles, budget);
    double support_seconds = 0;
    for (const auto &role : result.at("roles").items())
        if (role.key().rfind("support_", 0) == 0) support_seconds += role.value().at("seconds").get<double>();
    result["support_seconds"] = support_seconds;
    result["basis"] = "shared_orca_sections_support_region_proxy";
    return result;
}
