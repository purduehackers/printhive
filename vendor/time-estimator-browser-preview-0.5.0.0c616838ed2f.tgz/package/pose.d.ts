import type { Bounds } from './index.js';
export const IDENTITY_ROTATION: readonly number[];
export function poseMatrix(rotation?: readonly number[], mirrorX?: boolean, scale?: number): number[];
export function multiplyRotations(a: readonly number[], b: readonly number[]): number[];
export function rotationForFace(normal: number[]): number[];
export function extendBounds(bounds: Bounds, matrix: number[], point: ArrayLike<number>): void;
export function placeOnBed(matrix: number[], bounds: Bounds, bedCenter?: number[]): {sourceToPlate: number[]; bounds: Bounds};
export function createSTLWriter(triangleCount: number, transform: number[]): {addTriangle(vertices: number[]): void; finish(): Blob};
