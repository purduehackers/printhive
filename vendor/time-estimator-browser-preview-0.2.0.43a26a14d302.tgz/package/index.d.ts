export type Bounds = { min: number[]; max: number[] };
export type Mesh = { positions: Float32Array; indices?: Uint32Array };
export interface Limits { maxTriangles: number; maxGcodeBytes: number; maxSegments: number; timeoutMs: number }
export interface PreviewProfile {
  id: string;
  label: string;
  basis?: string;
  configuration: Record<string, unknown>;
}
export interface PreviewRequest<T = Mesh> {
  input: T;
  profile: PreviewProfile;
  support: 'tree' | 'normal' | 'none';
  view?: 'supports' | 'print';
  mirrorX?: boolean;
  layerHeight?: number;
  infill?: number;
  limits?: Partial<Limits>;
}
export interface PreviewProgress { stage: string; percent: number; message: string }
export interface SupportPreview {
  schemaVersion: 1;
  generationKey: string;
  status: 'ready' | 'disabled';
  view?: 'supports' | 'print';
  /** Packed x0,y0,z0,x1,y1,z1,width,height,role in canonical Z-up millimeters. Roles: 1 support, 2 interface; print view includes the features registry. */
  segments: Float64Array;
  layers: Array<{ printZ: number; height: number; startSegment?: number; endSegment?: number }>;
  features?: Array<{ id: number; name: string; color: string; category: string }>;
  segmentCount: number;
  bounds: Bounds;
  sourceToPlate: number[];
  provenance: Record<string, unknown>;
  warnings: Array<{ code: string; message: string }>;
  time: { estimatedSeconds: number; basis: 'orca_gcode_processor'; physicalCalibration: false; upperSeconds: null } | null;
  computeMilliseconds?: number;
}
export class PreviewError extends Error { code: string; details: Record<string, unknown>; constructor(code: string, message: string, details?: Record<string, unknown>) }
export const DEFAULT_LIMITS: Readonly<Limits>;
export interface PreviewClient<T = Mesh> {
  generate(request: PreviewRequest<T>, options?: { onProgress?: (progress: PreviewProgress) => void }): Promise<SupportPreview>;
  cancel(): void;
  dispose(): void;
}
export function createPreviewClient<T = Mesh>(options: { manifestUrl: string; workerFactory?: () => Worker; limits?: Partial<Limits> }): PreviewClient<T>;
