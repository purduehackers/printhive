import * as THREE from 'three';
import { SEGMENT_STRIDE, SUPPORT_BASE, SUPPORT_INTERFACE } from './gcode.mjs';
import { requireValue } from './errors.mjs';
import { PRINT_FEATURES } from './features.mjs';

const faces = [0,2,1,0,3,2,4,5,6,4,6,7,0,1,5,0,5,4,1,2,6,1,6,5,2,3,7,2,7,6,3,0,4,3,4,7];

/** Batched rectangular-bead presentation of actual generated extrusion paths (not support generation). */
function createOverlay(preview, features, { chunkSegments = 4096 } = {}) {
  requireValue(preview?.schemaVersion === 1 && preview.segments instanceof Float64Array &&
    preview.segments.length % SEGMENT_STRIDE === 0, 'invalid_preview', 'Invalid support preview payload');
  requireValue(Number.isSafeInteger(chunkSegments) && chunkSegments > 0 && chunkSegments <= 65536,
    'invalid_preview', 'Invalid render chunk size');
  const group = new THREE.Group();
  group.name = 'printed-toolpaths';
  const knownRoles = new Set(PRINT_FEATURES.map(feature => feature.id));
  const materials = new Map(features.map(feature => [feature.id,
    new THREE.MeshStandardMaterial({ color: feature.color, roughness: 0.7, side: THREE.DoubleSide })]));
  const geometries = [];
  const batches = [];
  let disposed = false;
  try {
    for (const feature of features) {
      const role = feature.id;
      let positions = new Float32Array(chunkSegments * 24), indices = new Uint32Array(chunkSegments * 36), count = 0;
      const segmentIds = new Uint32Array(chunkSegments);
      const flush = () => {
        if (!count) return;
        const geometry = new THREE.BufferGeometry();
        geometry.setAttribute('position', new THREE.BufferAttribute(positions.slice(0, count * 24), 3));
        geometry.setIndex(new THREE.BufferAttribute(indices.slice(0, count * 36), 1));
        geometry.computeVertexNormals(); geometry.computeBoundingSphere();
        geometries.push(geometry);
        const mesh = new THREE.Mesh(geometry, materials.get(role));
        mesh.name = feature.name;
        batches.push({ mesh, role, segmentIds: segmentIds.slice(0, count), count });
        group.add(mesh); count = 0;
      };
      const segments = preview.segments;
      for (let i = 0; i < segments.length; i += SEGMENT_STRIDE) {
        const [x0,y0,z0,x1,y1,z1,width,height,pathRole] = segments.subarray(i, i + SEGMENT_STRIDE);
        requireValue([x0,y0,z0,x1,y1,z1,width,height,pathRole].every(Number.isFinite) && width > 0 && height > 0 &&
          knownRoles.has(pathRole), 'invalid_preview', 'Invalid printed segment');
        if (pathRole !== role) continue;
        const length = Math.hypot(x1 - x0, y1 - y0);
        if (length < 1e-8) continue;
        requireValue(Math.abs(z1 - z0) < 1e-4, 'invalid_preview', 'Only planar support beads are supported');
        const dx = -(y1-y0) / length * width / 2, dy = (x1-x0) / length * width / 2;
        // printZ is the top of the physical layer, not the bead center.
        positions.set([x0+dx,y0+dy,z0-height,x1+dx,y1+dy,z1-height,x1-dx,y1-dy,z1-height,x0-dx,y0-dy,z0-height,
          x0+dx,y0+dy,z0,x1+dx,y1+dy,z1,x1-dx,y1-dy,z1,x0-dx,y0-dy,z0], count * 24);
        for (let k = 0; k < faces.length; ++k) indices[count * 36 + k] = count * 8 + faces[k];
        segmentIds[count] = i / SEGMENT_STRIDE;
        if (++count === chunkSegments) flush();
      }
      flush();
    }
  } catch (error) {
    for (const geometry of geometries) geometry.dispose();
    for (const material of materials.values()) material.dispose();
    throw error;
  }
  function setLayerRange(minZ = -Infinity, maxZ = Infinity) {
    requireValue((minZ === -Infinity || Number.isFinite(minZ)) && (maxZ === Infinity || Number.isFinite(maxZ)) && minZ <= maxZ,
      'invalid_preview', 'Invalid layer range');
    let sceneRoot = group;
    while (sceneRoot.parent) sceneRoot = sceneRoot.parent;
    sceneRoot.updateMatrixWorld(true);
    const planes = [];
    if (maxZ !== Infinity) planes.push(new THREE.Plane(new THREE.Vector3(0, 0, -1), maxZ).applyMatrix4(group.matrixWorld));
    if (minZ !== -Infinity) planes.push(new THREE.Plane(new THREE.Vector3(0, 0, 1), -minZ).applyMatrix4(group.matrixWorld));
    for (const material of materials.values()) material.clippingPlanes = planes;
  }
  function setMoveRange(start = 0, end = Infinity) {
    requireValue(Number.isSafeInteger(start) && start >= 0 &&
      (end === Infinity || Number.isSafeInteger(end) && end >= start), 'invalid_preview', 'Invalid move range');
    for (const batch of batches) {
      const lowerBound = value => {
        let low = 0, high = batch.count;
        while (low < high) {
          const mid = (low + high) >>> 1;
          if (batch.segmentIds[mid] < value) low = mid + 1; else high = mid;
        }
        return low;
      };
      const first = lowerBound(start), last = lowerBound(end);
      batch.mesh.geometry.setDrawRange(first * 36, (last - first) * 36);
    }
  }
  return {
    group,
    /** Requires renderer.localClippingEnabled; canonical Z is transformed into world coordinates. */
    setHeight(printZ = Infinity) {
      requireValue(printZ === Infinity || Number.isFinite(printZ), 'invalid_preview', 'Invalid clipping height');
      setLayerRange(-Infinity, printZ);
    },
    setLayerRange,
    setMoveRange,
    /** Reveal extrusion segments in their original G-code order, without rebuilding geometry. */
    setEndMove(end = Infinity) {
      requireValue(end === Infinity || Number.isSafeInteger(end) && end >= 0, 'invalid_preview', 'Invalid move index');
      setMoveRange(0, end);
    },
    setFeatureVisible(role, visible) {
      for (const batch of batches) if (batch.role === role) batch.mesh.visible = Boolean(visible);
    },
    setVisible(visible) { group.visible = Boolean(visible); },
    dispose() {
      if (disposed) return;
      disposed = true; group.removeFromParent();
      for (const geometry of geometries) geometry.dispose();
      for (const material of materials.values()) material.dispose();
      group.clear();
    },
  };
}

export function createToolpathOverlay(preview, options = {}) {
  return createOverlay(preview, PRINT_FEATURES, options);
}

export function createSupportOverlay(preview, { baseColor = '#427f9e', interfaceColor = '#bc7031', ...options } = {}) {
  return createOverlay(preview, [
    { id: SUPPORT_BASE, name: 'Support', color: baseColor },
    { id: SUPPORT_INTERFACE, name: 'Support interface', color: interfaceColor },
  ], options);
}
