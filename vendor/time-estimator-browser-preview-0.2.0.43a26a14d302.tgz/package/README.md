# Standalone browser print preview

An independently packaged browser library for sliced FDM layers and generated support inspection. It runs an
externally supplied Orca C++ WebAssembly engine in a dedicated Worker and optionally adds a
batched toolpath overlay to an existing Three.js scene. It contains no React, PrintHive, database,
native executable, server SDK, or Node worker dependency. The core entry does not import Three.js.

This package is private pending a project distribution license. Local integration is supported;
it has not been published. See [NOTICE.md](NOTICE.md).

## Use with your own viewer

```js
import { createPreviewClient } from '@time-estimator/browser-preview';
import { createToolpathOverlay } from '@time-estimator/browser-preview/three';

const client = createPreviewClient({ manifestUrl: '/preview-engine/manifest.json' });
const result = await client.generate({
  input: { positions, indices }, // complete Float32 XYZ and optional Uint32 triangle indices
  profile: { id: 'my-profile-revision', label: 'My printer / process / filament', configuration },
  support: 'tree', view: 'print', mirrorX: false,
}, { onProgress: progress => console.log(progress.stage) });

const overlay = createToolpathOverlay(result);
scene.add(overlay.group); // result coordinates are canonical Z-up millimeters
renderer.localClippingEnabled = true;
overlay.setHeight(result.layers.at(-1)?.printZ);
// Single layer and original extrusion order, like a slicer's G-code preview:
const layer = result.layers[0];
overlay.setLayerRange(layer.printZ - layer.height, layer.printZ);
overlay.setMoveRange(layer.startSegment, layer.endSegment);
// Later: overlay.dispose(); client.dispose();
```

Supply an explicitly selected effective Orca configuration. Preset inheritance is not resolved in
JavaScript: unresolved inheritance is rejected. Orca initializes its full C++ defaults and applies
the supplied configuration; describe a defaults-plus-overrides scenario honestly in profile.basis.
The caller owns profile selection and versioning. Profile substitutions/unknown settings fail.
Request layerHeight and infill, when supplied, are declared process overrides. The support type
is explicitly selected; remaining style/gap/interface/bed policies come from the profile.

Only the default support style, rectangular beds, one full mesh/one material and planar printed paths are admitted by this
adapter. Input positions are millimeters, Z-up. The part is centered on the selected bed and its
bottom grounded. The returned column-major sourceToPlate matrix describes the placement.
Mirroring is an explicit X reflection around the source bounding-box center; triangle winding is
corrected before generation. Supports are regenerated after pose/configuration changes.

Do not supply a sampled display mesh. STL/STEP parsing is deliberately outside this package.
Reuse your importer in a custom Worker with `installSupportWorker({ decodeMesh })` from the
`/worker` entry. PrintHive uses its existing bounded STL parser there and retains every triangle
within the declared generation budget. The default Worker accepts an already decoded mesh.

## Display contract

Result schema 1 contains Float64 segments with stride 9:
`x0,y0,z0,x1,y1,z1,width,height,role`. All dimensions are millimeters in canonical plate space.
`view: 'print'` returns model and support extrusions, including walls, infill, surfaces, bridges
and helpers. `features` identifies each used role with its Orca 2.4.2 label and default color.
Print layers contain actual print Z, height, and the zero-based `[startSegment,endSegment)`
interval in original G-code order. Supports set to `none` still generate the model's print paths.
The default `view: 'supports'` preserves support-only output (role 1 base, role 2 interface/contact),
including empty ready output versus disabled supports. Support-only layer heights can differ
from the object's layers. Generation keys cover the view, geometry, mirrored topology, pose, effective settings,
profile/runtime/extractor identities. These identities are separate from native .tecache states.

`createToolpathOverlay` uses Orca's feature palette; `createSupportOverlay` retains the original
two-color support-only adapter. Both use rectangular beads with occupied Z interval printZ-height..printZ.
This is an approximation of the appearance of the generated extrusion, not a printable solid or
a physical support-strength simulation. Groups/chunks reduce draw calls; resources are explicitly
disposed. `setLayerRange(minZ,maxZ)` clips to a layer or stack; `setEndMove(exclusiveIndex)`
reveals extrusion order across feature batches without rebuilding geometry. `setMoveRange(start,end)`
selects exactly the current layer's paths, including differing support/model bead heights. `setFeatureVisible`
toggles a role. Playback speed is owned by the host; segment progression is not physical timing.
Parent transforms are respected when clipping. `displayTransform(bounds)` provides
the normalized, Y-up camera presentation used by PrintHive; apply the same matrix to both model
and supports. Do not normalize supports independently or apply mirroring twice.

Generated G-code from Orca ABI 1 is decoded only for presentation. The reader tracks Cartesian
absolute/relative moves, extrusion modes/reset, dimensions, native feature roles and XY I/J arcs. Arc
display chords have <=0.02 mm sagitta and <=1 mm length. Unsupported inch/workspace/G92 XYZ,
nonplanar extrusion or missing dimensions fails rather than inventing geometry. No
time estimate is calculated from these paths. Time/material statistics come from Orca's C++
GCodeProcessor; returned time is an uncalibrated slicer reference with no physical upper bound.
This release does not implement the separate sampled fast estimator in the browser.

## Runtime and lifecycle

Provision an external serial runtime independently of the package:

```sh
node node_modules/@time-estimator/browser-preview/scripts/fetch-runtime.mjs public/preview-engine
```

The fetch tool verifies the fixed SHA-256 lock and refuses changed/existing mismatched assets.
It supports Node or Bun and requires no native estimator installation. Serve the resulting public
assets from the same origin with the manifest. The browser independently verifies all asset
hashes before importing glue and instantiating WASM, and checks the engine version/ABI. The
lock records a tested external binary with unknown exact source revision; it is not evidence of
universal native parity. A host can supply another compatible checksummed manifest explicitly.

Only requested engine files are fetched; input geometry is never uploaded by this package.
The serial engine needs no cross-origin isolation. Blob module imports must be allowed by the
host's content policy. HTTPS or localhost is required for browser crypto. Initialization and slicing
share the request deadline. Cancel/replacement/disposal terminates the dedicated Worker and its
heap; synchronous C++ work does not need to service a cancellation message. No persistent cache
or worker survives a completed request. Mutable job/profile scheduling remains caller-owned.

Default admission: 250,000 triangles, 250,000 displayed extrusion segments, 64 MiB generated G-code and
30 seconds. These are limits, not device guarantees. A WASM memory limit does not include GPU,
transport or viewer buffers; hosts should narrow admission for their tested devices. Runtime traps,
download/integrity failures, unsupported output, allocation limits and deadlines are structured
PreviewErrors. A failed preview must not disable the host's file submission.

## Development and validation

```sh
bun install --frozen-lockfile
bun run test
bun run check
# Fetch runtime first; PREVIEW_RUNTIME can select its directory.
bun run test:runtime
bun run test:browser
```

Tests cover transforms/mirroring, modal path extraction and arcs, feature/layer intervals, budgets,
ordered playback across render chunks, clipping/resource disposal, worker cancellation, full print
paths with supports disabled and real synthetic tree generation when the external runtime is
provisioned. Browser tests exercise the actual default Worker, integrity loader, WASM and renderer.
Native/physical parity, mobile limits and broad real-model performance remain separate validation.

The root CMake build, native SDK installation/source archive and bindings/typescript package do
not depend on or package this browser library. Pack this directory separately for a consumer;
Three.js is optional unless that consumer imports the `/three` entry.
