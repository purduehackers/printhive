import type { Group } from 'three';
import type { SupportPreview } from './index.js';
export interface SupportOverlay {
  group: Group;
  setHeight(printZ?: number): void;
  setLayerRange(minZ?: number, maxZ?: number): void;
  setMoveRange(start?: number, end?: number): void;
  setEndMove(end?: number): void;
  setFeatureVisible(role: number, visible: boolean): void;
  setVisible(visible: boolean): void;
  dispose(): void;
}
export function createSupportOverlay(preview: SupportPreview, options?: { baseColor?: string; interfaceColor?: string; chunkSegments?: number }): SupportOverlay;
export function createToolpathOverlay(preview: SupportPreview, options?: { chunkSegments?: number }): SupportOverlay;
