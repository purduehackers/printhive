import { loadOrcaRuntime } from './engine.mjs';
import { PreviewError } from './errors.mjs';

/** A host can decode a File with its existing importer in this worker, without a UI-thread copy. */
export function installSupportWorker({ decodeMesh = async (input) => input } = {}) {
  let busy = false;
  globalThis.onmessage = async ({ data }) => {
    const { id, request, manifestUrl, operation = 'generate' } = data ?? {};
    if (busy) {
      globalThis.postMessage({
        id,
        type: 'error',
        error: { code: 'busy', message: 'Support worker is already running' },
      });
      return;
    }
    busy = true;
    try {
      const progress = (value) => globalThis.postMessage({ id, type: 'progress', progress: value });
      progress({ stage: 'reading_model', percent: 0, message: 'Reading complete model' });
      const mesh = await decodeMesh(request.input, request.limits);
      let result;
      if (operation === 'fast') {
        const { estimateFast } = await import('./fast.mjs');
        result = await estimateFast(request, mesh);
      } else {
        const runtime = await loadOrcaRuntime(manifestUrl, progress);
        result =
          operation === 'orient'
            ? await runtime.orient(request, mesh)
            : await runtime.generate(request, mesh);
      }
      globalThis.postMessage({ id, type: 'result', result }, result.segments ? [result.segments.buffer] : []);
    } catch (error) {
      globalThis.postMessage({
        id,
        type: 'error',
        error: {
          code: error instanceof PreviewError ? error.code : 'worker_error',
          message: error.message || 'Could not generate supports',
          details: error.details ?? {},
        },
      });
    } finally {
      busy = false;
    }
  };
}
