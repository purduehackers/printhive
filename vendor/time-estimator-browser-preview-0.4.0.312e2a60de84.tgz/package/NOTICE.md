# Distribution and dependencies

This browser package is separate from the native time_estimator SDK and its Node worker client.
Newly authored project code has no selected redistribution license; this package remains private.
Local packing and application integration do not authorize publication.

Three.js is an optional peer under its own MIT license. Orca is an independently supplied
WebAssembly engine, not part of this package or the server SDK. Its code and browser port retain
their upstream AGPL notices and source obligations. The development fetch tools provision a
checksummed external slicing build only when requested; that slicing engine is not packed here.
The source-to-binary equivalence of that external build has not been established by this project.

The separate browser STL importer is bundled as a prebuilt WebAssembly module. It reuses the
source-matched C++ import program, Orca's retained ADMesh sources and Eigen 5.0.1. Their GPL,
AGPL, Eigen and Emscripten runtime license notices are in repair/licenses. Source/build identities are recorded in
repair/build.json; repair/README.md describes rebuilding from the complete source checkout.
This importer does not link or distribute the native/server estimator library.

The optional quick-time kernel independently compiles the existing native sampled estimator
with Clipper2 1.5.4 and nlohmann/json 3.12.0. Notices and build identities are in fast/.
It does not link the server estimator. Its Orca default snapshot is derived from the pinned
engine's configuration descriptor; the associated Orca notices above still apply.

Engine source: https://github.com/JoshTheDerf/orcaslicer-wasm
Orca source and license: https://github.com/OrcaSlicer/OrcaSlicer
Three.js source and license: https://github.com/mrdoob/three.js

SHA-256 fallback: unchanged @noble/hashes 2.0.1 modules under the MIT license.
Source identity and license are retained in vendor/noble-hashes. Web Crypto remains the
preferred hashing path; this fallback preserves checksums on ordinary HTTP development origins.
