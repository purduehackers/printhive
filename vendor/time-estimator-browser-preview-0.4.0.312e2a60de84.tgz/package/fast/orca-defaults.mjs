export default {
  "engine": {
    "name": "orca",
    "version": "2.4.2",
    "bridge": 1
  },
  "runtimeSha256": "ce4c53638636f4b95f2c2269784adc6e2754a9064a6912fe4ca474dd505b42dd",
  "configuration": {
    "absolute_correction": "0",
    "accel_to_decel_enable": "1",
    "accel_to_decel_factor": "50%",
    "activate_air_filtration": [
      "0"
    ],
    "activate_air_filtration_during_print": [
      "1"
    ],
    "activate_air_filtration_on_completion": [
      "1"
    ],
    "activate_chamber_temp_control": [
      "0"
    ],
    "adaptive_bed_mesh_margin": "0",
    "adaptive_pressure_advance": [
      "0"
    ],
    "adaptive_pressure_advance_bridges": [
      "0"
    ],
    "adaptive_pressure_advance_model": "\"0,0,0\\n0,0,0\"",
    "adaptive_pressure_advance_overhangs": [
      "0"
    ],
    "additional_cooling_fan_speed": [
      "0"
    ],
    "additional_fan_full_speed_layer": [
      "0"
    ],
    "align_infill_direction_to_model": "0",
    "alternate_extra_wall": "0",
    "area_fill": "50",
    "auxiliary_fan": "0",
    "bbl_calib_mark_logo": "1",
    "bbl_use_printhost": "0",
    "bed_custom_model": "",
    "bed_custom_texture": "",
    "bed_exclude_area": "0x0",
    "bed_mesh_max": "99999,99999",
    "bed_mesh_min": "-99999,-99999",
    "bed_mesh_probe_distance": "50,50",
    "bed_temperature_formula": "by_highest_temp",
    "before_layer_change_gcode": "",
    "best_object_pos": "0.5,0.5",
    "bottle_cost": "0",
    "bottle_volume": "1000",
    "bottle_weight": "1",
    "bottom_shell_layers": "3",
    "bottom_shell_thickness": "0",
    "bottom_solid_infill_flow_ratio": "1",
    "bottom_surface_density": "100%",
    "bottom_surface_filament_id": "0",
    "bottom_surface_pattern": "monotonic",
    "bridge_acceleration": "50%",
    "bridge_angle": "0",
    "bridge_density": "100%",
    "bridge_flow": "1",
    "bridge_line_width": "100%",
    "bridge_no_support": "0",
    "bridge_speed": "25",
    "brim_ears": "0",
    "brim_ears_detection_length": "1",
    "brim_ears_max_angle": "125",
    "brim_flow_ratio": "1",
    "brim_object_gap": "0",
    "brim_type": "auto_brim",
    "brim_use_efc_outline": "0",
    "brim_width": "0",
    "calib_flowrate_topinfill_special_order": "0",
    "chamber_minimal_temperature": [
      "0"
    ],
    "chamber_temperature": [
      "0"
    ],
    "change_extrusion_role_gcode": "",
    "change_filament_gcode": "",
    "close_additional_fan_first_x_layers": [
      "1"
    ],
    "close_fan_the_first_x_layers": [
      "1"
    ],
    "combine_brims": "0",
    "compatible_machine_expression_group": "",
    "compatible_printers": "",
    "compatible_printers_condition": "",
    "compatible_prints": "",
    "compatible_prints_condition": "",
    "compatible_process_expression_group": "",
    "complete_print_exhaust_fan_speed": [
      "80"
    ],
    "cool_plate_temp": [
      "35"
    ],
    "cool_plate_temp_initial_layer": [
      "35"
    ],
    "cooling_tube_length": "5",
    "cooling_tube_retraction": "91.5",
    "counterbore_hole_bridging": "none",
    "curr_bed_type": "Cool Plate",
    "default_acceleration": "500",
    "default_bed_type": "",
    "default_filament_colour": "\"\"",
    "default_filament_profile": "",
    "default_jerk": "0",
    "default_junction_deviation": "0",
    "default_nozzle_volume_type": "Standard",
    "default_print_profile": "",
    "default_sla_material_profile": "",
    "default_sla_print_profile": "",
    "deretraction_speed": [
      "0"
    ],
    "detect_narrow_internal_solid_infill": "1",
    "detect_overhang_wall": "1",
    "detect_thin_wall": "0",
    "different_settings_to_system": "",
    "disable_m73": "0",
    "display_height": "68",
    "display_mirror_x": "1",
    "display_mirror_y": "0",
    "display_orientation": "portrait",
    "display_pixels_x": "2560",
    "display_pixels_y": "1440",
    "display_width": "120",
    "dont_filter_internal_bridges": "disabled",
    "dont_slow_down_outer_wall": [
      "0"
    ],
    "draft_shield": "disabled",
    "during_print_exhaust_fan_speed": [
      "60"
    ],
    "elefant_foot_compensation": "0",
    "elefant_foot_compensation_layers": "1",
    "elefant_foot_layers_density": "100%",
    "elefant_foot_min_width": "0.2",
    "emit_machine_limits_to_gcode": "1",
    "enable_arc_fitting": "0",
    "enable_extra_bridge_layer": "disabled",
    "enable_filament_dynamic_map": "0",
    "enable_filament_ramming": "1",
    "enable_long_retraction_when_cut": "0",
    "enable_overhang_bridge_fan": [
      "1"
    ],
    "enable_overhang_speed": "1",
    "enable_power_loss_recovery": "printer_configuration",
    "enable_pressure_advance": [
      "0"
    ],
    "enable_prime_tower": "0",
    "enable_support": "0",
    "enable_tower_interface_cooldown_during_tower": "0",
    "enable_tower_interface_features": "0",
    "enable_wrapping_detection": "0",
    "enforce_support_layers": "0",
    "eng_plate_temp": [
      "45"
    ],
    "eng_plate_temp_initial_layer": [
      "45"
    ],
    "ensure_vertical_shell_thickness": "ensure_all",
    "exclude_object": "0",
    "exposure_time": "10",
    "extra_loading_move": "-2",
    "extra_perimeters_on_overhangs": "0",
    "extra_solid_infills": "",
    "extruder": "",
    "extruder_ams_count": "",
    "extruder_clearance_height_to_lid": "120",
    "extruder_clearance_height_to_rod": "40",
    "extruder_clearance_radius": "40",
    "extruder_colour": "\"\"",
    "extruder_offset": "0x0",
    "extruder_printable_area": "",
    "extruder_printable_height": [
      "0"
    ],
    "extruder_type": "Direct Drive",
    "extruder_variant_list": "\"Direct Drive Standard\"",
    "extrusion_rate_smoothing_external_perimeter_only": "0",
    "faded_layers": "10",
    "fan_cooling_layer_time": [
      "60"
    ],
    "fan_kickstart": "0",
    "fan_max_speed": [
      "100"
    ],
    "fan_min_speed": [
      "20"
    ],
    "fan_speedup_overhangs": "1",
    "fan_speedup_time": "0",
    "fast_tilt_time": "5",
    "filament_adaptive_volumetric_speed": [
      "0"
    ],
    "filament_adhesiveness_category": [
      "0"
    ],
    "filament_change_extrusion_role_gcode": "\"\"",
    "filament_change_length": [
      "10"
    ],
    "filament_colour": "#F2754E",
    "filament_colour_type": "1",
    "filament_cooling_before_tower": [
      "10"
    ],
    "filament_cooling_final_speed": [
      "3.4"
    ],
    "filament_cooling_initial_speed": [
      "2.2"
    ],
    "filament_cooling_moves": [
      "4"
    ],
    "filament_cost": [
      "0"
    ],
    "filament_density": [
      "0"
    ],
    "filament_deretraction_speed": [
      "0"
    ],
    "filament_diameter": [
      "1.75"
    ],
    "filament_end_gcode": "\" \"",
    "filament_extruder_variant": "\"Direct Drive Standard\"",
    "filament_flow_ratio": [
      "1"
    ],
    "filament_flush_temp": [
      "0"
    ],
    "filament_flush_volumetric_speed": [
      "0"
    ],
    "filament_ids": "",
    "filament_ironing_flow": [
      "nil"
    ],
    "filament_ironing_inset": [
      "nil"
    ],
    "filament_ironing_spacing": [
      "nil"
    ],
    "filament_ironing_speed": [
      "nil"
    ],
    "filament_is_support": [
      "0"
    ],
    "filament_loading_speed": [
      "28"
    ],
    "filament_loading_speed_start": [
      "3"
    ],
    "filament_long_retractions_when_cut": [
      "0"
    ],
    "filament_map": [
      "1"
    ],
    "filament_map_mode": "Auto For Flush",
    "filament_max_volumetric_speed": [
      "2"
    ],
    "filament_minimal_purge_on_wipe_tower": [
      "15"
    ],
    "filament_multi_colour": "\"\"",
    "filament_multitool_ramming": [
      "0"
    ],
    "filament_multitool_ramming_flow": [
      "10"
    ],
    "filament_multitool_ramming_volume": [
      "10"
    ],
    "filament_notes": "\"\"",
    "filament_printable": [
      "3"
    ],
    "filament_ramming_parameters": "\"120 100 6.6 6.8 7.2 7.6 7.9 8.2 8.7 9.4 9.9 10.0| 0.05 6.6 0.45 6.8 0.95 7.8 1.45 8.3 1.95 9.7 2.45 10 2.95 7.6 3.45 7.6 3.95 7.6 4.45 7.6 4.95 7.6\"",
    "filament_retract_before_wipe": [
      "100%"
    ],
    "filament_retract_lift_above": [
      "0"
    ],
    "filament_retract_lift_below": [
      "0"
    ],
    "filament_retract_lift_enforce": "All Surfaces",
    "filament_retract_restart_extra": [
      "0"
    ],
    "filament_retract_when_changing_layer": [
      "0"
    ],
    "filament_retraction_distances_when_cut": [
      "18"
    ],
    "filament_retraction_length": [
      "0.8"
    ],
    "filament_retraction_minimum_travel": [
      "2"
    ],
    "filament_retraction_speed": [
      "30"
    ],
    "filament_self_index": [
      "1"
    ],
    "filament_settings_id": "\"\"",
    "filament_shrink": [
      "100%"
    ],
    "filament_shrinkage_compensation_z": [
      "100%"
    ],
    "filament_soluble": [
      "0"
    ],
    "filament_stamping_distance": [
      "0"
    ],
    "filament_stamping_loading_speed": [
      "0"
    ],
    "filament_start_gcode": "\" \"",
    "filament_toolchange_delay": [
      "0"
    ],
    "filament_tower_interface_pre_extrusion_dist": [
      "10"
    ],
    "filament_tower_interface_pre_extrusion_length": [
      "0"
    ],
    "filament_tower_interface_print_temp": [
      "-1"
    ],
    "filament_tower_interface_purge_volume": [
      "20"
    ],
    "filament_tower_ironing_area": [
      "4"
    ],
    "filament_type": "PLA",
    "filament_unloading_speed": [
      "90"
    ],
    "filament_unloading_speed_start": [
      "100"
    ],
    "filament_vendor": "(Undefined)",
    "filament_wipe": [
      "0"
    ],
    "filament_wipe_distance": [
      "1"
    ],
    "filament_z_hop": [
      "0.4"
    ],
    "filament_z_hop_types": "Slope Lift",
    "file_start_gcode": "",
    "filename_format": "{input_filename_base}_{filament_type[initial_tool]}_{print_time}.gcode",
    "fill_multiline": "1",
    "filter_out_gap_fill": "0",
    "first_layer_flow_ratio": "1",
    "first_layer_print_sequence": [
      "0"
    ],
    "first_layer_sequence_choice": "Auto",
    "first_x_layer_fan_speed": [
      "0"
    ],
    "flashforge_serial_number": "",
    "flush_into_infill": "0",
    "flush_into_objects": "0",
    "flush_into_support": "1",
    "flush_multiplier": [
      "0.3"
    ],
    "flush_volumes_matrix": [
      "0",
      "280",
      "280",
      "280",
      "280",
      "0",
      "280",
      "280",
      "280",
      "280",
      "0",
      "280",
      "280",
      "280",
      "280",
      "0"
    ],
    "flush_volumes_vector": [
      "140",
      "140",
      "140",
      "140",
      "140",
      "140",
      "140",
      "140"
    ],
    "full_fan_speed_layer": [
      "0"
    ],
    "fuzzy_skin": "disabled_fuzzy",
    "fuzzy_skin_first_layer": "0",
    "fuzzy_skin_layers_between_ripple_offset": "1",
    "fuzzy_skin_mode": "displacement",
    "fuzzy_skin_noise_type": "classic",
    "fuzzy_skin_octaves": "4",
    "fuzzy_skin_persistence": "0.5",
    "fuzzy_skin_point_distance": "0.3",
    "fuzzy_skin_ripple_offset": "50%",
    "fuzzy_skin_ripples_per_layer": "15",
    "fuzzy_skin_scale": "1",
    "fuzzy_skin_thickness": "0.2",
    "gamma_correction": "1",
    "gap_fill_flow_ratio": "1",
    "gap_fill_target": "nowhere",
    "gap_infill_speed": "30",
    "gcode_add_line_number": "0",
    "gcode_comments": "0",
    "gcode_flavor": "marlin",
    "gcode_label_objects": "1",
    "grab_length": [
      "0"
    ],
    "gyroid_optimized": "0",
    "has_filament_switcher": "0",
    "has_scarf_joint_seam": "0",
    "head_wrap_detect_zone": "",
    "high_current_on_filament_swap": "0",
    "hole_to_polyhole": "0",
    "hole_to_polyhole_threshold": "0.01",
    "hole_to_polyhole_twisted": "1",
    "hollowing_closing_distance": "2",
    "hollowing_enable": "0",
    "hollowing_min_thickness": "3",
    "hollowing_quality": "0.5",
    "host_type": "octoprint",
    "hot_plate_temp": [
      "45"
    ],
    "hot_plate_temp_initial_layer": [
      "45"
    ],
    "idle_temperature": [
      "0"
    ],
    "independent_support_layer_height": "1",
    "infill_anchor": "400%",
    "infill_anchor_max": "20",
    "infill_combination": "0",
    "infill_combination_max_layer_height": "100%",
    "infill_direction": "45",
    "infill_jerk": "9",
    "infill_lock_depth": "1",
    "infill_overhang_angle": "60",
    "infill_shift_step": "0.4",
    "infill_wall_overlap": "15%",
    "inherits": "",
    "inherits_group": "",
    "initial_exposure_time": "15",
    "initial_layer_acceleration": "300",
    "initial_layer_height": "0.3",
    "initial_layer_infill_speed": "60",
    "initial_layer_jerk": "9",
    "initial_layer_line_width": "0",
    "initial_layer_min_bead_width": "85%",
    "initial_layer_print_height": "0.2",
    "initial_layer_speed": "30",
    "initial_layer_travel_acceleration": "100%",
    "initial_layer_travel_jerk": "100%",
    "initial_layer_travel_speed": "100%",
    "inner_wall_acceleration": "10000",
    "inner_wall_filament_id": "0",
    "inner_wall_flow_ratio": "1",
    "inner_wall_jerk": "9",
    "inner_wall_line_width": "0",
    "inner_wall_speed": "60",
    "input_shaping_damp_x": "0.1",
    "input_shaping_damp_y": "0.1",
    "input_shaping_emit": "0",
    "input_shaping_freq_x": "0",
    "input_shaping_freq_y": "0",
    "input_shaping_type": "Default",
    "interface_shells": "0",
    "interlocking_beam": "0",
    "interlocking_beam_layer_count": "2",
    "interlocking_beam_width": "0.8",
    "interlocking_boundary_avoidance": "2",
    "interlocking_depth": "2",
    "interlocking_orientation": "22.5",
    "internal_bridge_angle": "0",
    "internal_bridge_density": "100%",
    "internal_bridge_fan_speed": [
      "-1"
    ],
    "internal_bridge_flow": "1",
    "internal_bridge_speed": "150%",
    "internal_solid_filament_id": "0",
    "internal_solid_infill_acceleration": "100%",
    "internal_solid_infill_flow_ratio": "1",
    "internal_solid_infill_line_width": "0",
    "internal_solid_infill_pattern": "monotonic",
    "internal_solid_infill_speed": "100",
    "ironing_angle": "0",
    "ironing_angle_fixed": "0",
    "ironing_expansion": "0",
    "ironing_fan_speed": [
      "-1"
    ],
    "ironing_flow": "10%",
    "ironing_inset": "0",
    "ironing_pattern": "rectilinear",
    "ironing_spacing": "0.1",
    "ironing_speed": "20",
    "ironing_type": "no ironing",
    "is_infill_first": "0",
    "lateral_lattice_angle_1": "-45",
    "lateral_lattice_angle_2": "45",
    "layer_change_gcode": "",
    "layer_height": "0.2",
    "lightning_overhang_angle": "45",
    "lightning_prune_angle": "45",
    "lightning_straightening_angle": "45",
    "line_width": "0",
    "long_retractions_when_cut": [
      "0"
    ],
    "long_retractions_when_ec": [
      "0"
    ],
    "machine_end_gcode": "M104 S0 ; turn off temperature\\nG28 X0  ; home X axis\\nM84     ; disable motors\\n",
    "machine_load_filament_time": "0",
    "machine_max_acceleration_e": [
      "5000",
      "5000"
    ],
    "machine_max_acceleration_extruding": [
      "1500",
      "1250"
    ],
    "machine_max_acceleration_retracting": [
      "1500",
      "1250"
    ],
    "machine_max_acceleration_travel": [
      "0",
      "0"
    ],
    "machine_max_acceleration_x": [
      "1000",
      "1000"
    ],
    "machine_max_acceleration_y": [
      "1000",
      "1000"
    ],
    "machine_max_acceleration_z": [
      "500",
      "200"
    ],
    "machine_max_jerk_e": [
      "2.5",
      "2.5"
    ],
    "machine_max_jerk_x": [
      "10",
      "10"
    ],
    "machine_max_jerk_y": [
      "10",
      "10"
    ],
    "machine_max_jerk_z": [
      "0.2",
      "0.4"
    ],
    "machine_max_junction_deviation": [
      "0.01"
    ],
    "machine_max_speed_e": [
      "120",
      "120"
    ],
    "machine_max_speed_x": [
      "500",
      "200"
    ],
    "machine_max_speed_y": [
      "500",
      "200"
    ],
    "machine_max_speed_z": [
      "12",
      "12"
    ],
    "machine_min_extruding_rate": [
      "0",
      "0"
    ],
    "machine_min_travel_rate": [
      "0",
      "0"
    ],
    "machine_pause_gcode": "",
    "machine_start_gcode": "G28 ; home all axes\\nG1 Z5 F5000 ; lift nozzle\\n",
    "machine_tool_change_time": "0",
    "machine_unload_filament_time": "0",
    "make_overhang_printable": "0",
    "make_overhang_printable_angle": "55",
    "make_overhang_printable_hole_size": "0",
    "manual_filament_change": "0",
    "master_extruder_id": "1",
    "material_colour": "#29B2B2",
    "material_correction": [
      "1",
      "1",
      "1"
    ],
    "material_correction_x": "1",
    "material_correction_y": "1",
    "material_correction_z": "1",
    "material_density": "1",
    "material_print_speed": "fast",
    "material_type": "Tough",
    "material_vendor": "",
    "max_bridge_length": "10",
    "max_exposure_time": "100",
    "max_initial_exposure_time": "150",
    "max_layer_height": [
      "0"
    ],
    "max_resonance_avoidance_speed": "120",
    "max_travel_detour_distance": "0",
    "max_volumetric_extrusion_rate_slope": "0",
    "max_volumetric_extrusion_rate_slope_segment_length": "3",
    "min_bead_width": "85%",
    "min_exposure_time": "0",
    "min_feature_size": "25%",
    "min_initial_exposure_time": "0",
    "min_layer_height": [
      "0.07"
    ],
    "min_length_factor": "0.5",
    "min_resonance_avoidance_speed": "70",
    "min_skirt_length": "0",
    "min_width_top_surface": "300%",
    "minimum_sparse_infill_area": "15",
    "mmu_segmented_region_interlocking_depth": "0",
    "mmu_segmented_region_max_width": "0",
    "notes": "",
    "nozzle_diameter": [
      "0.4"
    ],
    "nozzle_flush_dataset": [
      "0"
    ],
    "nozzle_height": "2.5",
    "nozzle_hrc": "0",
    "nozzle_temperature": [
      "200"
    ],
    "nozzle_temperature_initial_layer": [
      "200"
    ],
    "nozzle_temperature_range_high": [
      "240"
    ],
    "nozzle_temperature_range_low": [
      "190"
    ],
    "nozzle_type": "undefine",
    "nozzle_volume": [
      "0"
    ],
    "nozzle_volume_type": "Standard",
    "only_one_wall_first_layer": "0",
    "only_one_wall_top": "0",
    "ooze_prevention": "0",
    "other_layers_print_sequence": [
      "0"
    ],
    "other_layers_print_sequence_nums": "0",
    "other_layers_sequence_choice": "Auto",
    "outer_wall_acceleration": "500",
    "outer_wall_filament_id": "0",
    "outer_wall_flow_ratio": "1",
    "outer_wall_jerk": "9",
    "outer_wall_line_width": "0",
    "outer_wall_speed": "60",
    "overhang_1_4_speed": "0",
    "overhang_2_4_speed": "0",
    "overhang_3_4_speed": "0",
    "overhang_4_4_speed": "0",
    "overhang_fan_speed": [
      "100"
    ],
    "overhang_fan_threshold": "95%",
    "overhang_flow_ratio": "1",
    "overhang_reverse": "0",
    "overhang_reverse_internal_only": "0",
    "overhang_reverse_threshold": "50%",
    "pad_around_object": "0",
    "pad_around_object_everywhere": "0",
    "pad_brim_size": "1.6",
    "pad_enable": "1",
    "pad_max_merge_distance": "50",
    "pad_object_connector_penetration": "0.3",
    "pad_object_connector_stride": "10",
    "pad_object_connector_width": "0.5",
    "pad_object_gap": "1",
    "pad_wall_height": "0",
    "pad_wall_slope": "90",
    "pad_wall_thickness": "2",
    "parallel_printheads_bed_exclude_areas": "",
    "parallel_printheads_count": "1",
    "parking_pos_retraction": "92",
    "part_cooling_fan_min_pwm": "0",
    "pellet_flow_coefficient": [
      "0.4157"
    ],
    "pellet_modded_printer": "0",
    "physical_extruder_map": [
      "0"
    ],
    "post_process": "",
    "precise_outer_wall": "1",
    "precise_z_height": "0",
    "preferred_orientation": "0",
    "preheat_steps": "1",
    "preheat_time": "30",
    "preset_name": "",
    "preset_names": "",
    "pressure_advance": [
      "0.02"
    ],
    "prime_tower_brim_width": "3",
    "prime_tower_enable_framework": "0",
    "prime_tower_flat_ironing": "0",
    "prime_tower_infill_gap": "150%",
    "prime_tower_skip_points": "1",
    "prime_tower_width": "60",
    "prime_volume": "45",
    "print_compatible_printers": "",
    "print_extruder_id": [
      "1"
    ],
    "print_extruder_variant": "\"Direct Drive Standard\"",
    "print_flow_ratio": "1",
    "print_host": "",
    "print_host_webui": "",
    "print_order": "default",
    "print_sequence": "by layer",
    "print_settings_id": "",
    "printable_area": "0x0,200x0,200x200,0x200",
    "printable_height": "100",
    "printer_agent": "",
    "printer_extruder_id": [
      "1"
    ],
    "printer_extruder_variant": "\"Direct Drive Standard\"",
    "printer_model": "",
    "printer_notes": "",
    "printer_settings_id": "",
    "printer_structure": "undefine",
    "printer_technology": "FFF",
    "printer_variant": "",
    "printhost_apikey": "",
    "printhost_authorization_type": "key",
    "printhost_cafile": "",
    "printhost_password": "",
    "printhost_port": "",
    "printhost_ssl_ignore_revoke": "0",
    "printhost_user": "",
    "printing_by_object_gcode": "",
    "process_change_extrusion_role_gcode": "",
    "purge_in_prime_tower": "1",
    "raft_contact_distance": "0.1",
    "raft_expansion": "1.5",
    "raft_first_layer_density": "90%",
    "raft_first_layer_expansion": "2",
    "raft_layers": "0",
    "reduce_crossing_wall": "0",
    "reduce_fan_stop_start_freq": [
      "0"
    ],
    "reduce_infill_retraction": "0",
    "relative_bridge_angle": "0",
    "relative_correction": [
      "1",
      "1"
    ],
    "relative_correction_x": "1",
    "relative_correction_y": "1",
    "relative_correction_z": "1",
    "required_nozzle_HRC": [
      "0"
    ],
    "resolution": "0.01",
    "resonance_avoidance": "0",
    "retract_before_wipe": [
      "100%"
    ],
    "retract_length_toolchange": [
      "10"
    ],
    "retract_lift_above": [
      "0"
    ],
    "retract_lift_below": [
      "0"
    ],
    "retract_lift_enforce": "All Surfaces",
    "retract_restart_extra": [
      "0"
    ],
    "retract_restart_extra_toolchange": [
      "0"
    ],
    "retract_when_changing_layer": [
      "0"
    ],
    "retraction_distances_when_cut": [
      "18"
    ],
    "retraction_distances_when_ec": [
      "10"
    ],
    "retraction_length": [
      "0.8"
    ],
    "retraction_minimum_travel": [
      "2"
    ],
    "retraction_speed": [
      "30"
    ],
    "role_based_wipe_speed": "1",
    "scan_first_layer": "0",
    "scarf_angle_threshold": "155",
    "scarf_joint_flow_ratio": "1",
    "scarf_joint_speed": "100%",
    "scarf_overhang_threshold": "40%",
    "seam_gap": "10%",
    "seam_position": "aligned",
    "seam_slope_conditional": "0",
    "seam_slope_entire_loop": "0",
    "seam_slope_inner_walls": "0",
    "seam_slope_min_length": "20",
    "seam_slope_start_height": "0",
    "seam_slope_steps": "10",
    "seam_slope_type": "none",
    "set_other_flow_ratios": "0",
    "silent_mode": "0",
    "single_extruder_multi_material": "1",
    "single_extruder_multi_material_priming": "0",
    "single_loop_draft_shield": "0",
    "skeleton_infill_density": "25%",
    "skeleton_infill_line_width": "100%",
    "skin_infill_density": "25%",
    "skin_infill_depth": "2",
    "skin_infill_line_width": "100%",
    "skirt_distance": "2",
    "skirt_height": "1",
    "skirt_loops": "1",
    "skirt_speed": "50",
    "skirt_start_angle": "-135",
    "skirt_type": "combined",
    "sla_material_settings_id": "",
    "sla_print_settings_id": "",
    "slice_closing_radius": "0.049",
    "slicing_mode": "regular",
    "slow_down_for_layer_cooling": [
      "1"
    ],
    "slow_down_layer_time": [
      "5"
    ],
    "slow_down_layers": "0",
    "slow_down_min_speed": [
      "10"
    ],
    "slow_tilt_time": "8",
    "slowdown_for_curled_perimeters": "0",
    "small_area_infill_flow_compensation": "0",
    "small_area_infill_flow_compensation_model": "0,0;\"\\n0.2,0.4444\";\"\\n0.4,0.6145\";\"\\n0.6,0.7059\";\"\\n0.8,0.7619\";\"\\n1.5,0.8571\";\"\\n2,0.8889\";\"\\n3,0.9231\";\"\\n5,0.9520\";\"\\n10,1\"",
    "small_perimeter_speed": "50%",
    "small_perimeter_threshold": "0",
    "solid_infill_direction": "45",
    "solid_infill_rotate_template": "",
    "sparse_infill_acceleration": "100%",
    "sparse_infill_density": "20%",
    "sparse_infill_filament_id": "0",
    "sparse_infill_flow_ratio": "1",
    "sparse_infill_line_width": "0",
    "sparse_infill_pattern": "crosshatch",
    "sparse_infill_rotate_template": "",
    "sparse_infill_speed": "100",
    "spiral_finishing_flow_ratio": "0",
    "spiral_mode": "0",
    "spiral_mode_max_xy_smoothing": "200%",
    "spiral_mode_smooth": "0",
    "spiral_starting_flow_ratio": "0",
    "staggered_inner_seams": "0",
    "standby_temperature_delta": "-5",
    "start_end_points": "30x-3,54x245",
    "supertack_plate_temp": [
      "35"
    ],
    "supertack_plate_temp_initial_layer": [
      "35"
    ],
    "support_air_filtration": "1",
    "support_angle": "0",
    "support_base_diameter": "4",
    "support_base_height": "1",
    "support_base_pattern": "default",
    "support_base_pattern_spacing": "2.5",
    "support_base_safety_distance": "1",
    "support_bottom_interface_spacing": "0.5",
    "support_bottom_z_distance": "0.2",
    "support_buildplate_only": "0",
    "support_chamber_temp_control": "1",
    "support_critical_angle": "45",
    "support_critical_regions_only": "0",
    "support_expansion": "0",
    "support_filament": "0",
    "support_flow_ratio": "1",
    "support_head_front_diameter": "0.4",
    "support_head_penetration": "0.2",
    "support_head_width": "1",
    "support_interface_bottom_layers": "0",
    "support_interface_filament": "0",
    "support_interface_flow_ratio": "1",
    "support_interface_loop_pattern": "0",
    "support_interface_not_for_body": "1",
    "support_interface_pattern": "auto",
    "support_interface_spacing": "0.5",
    "support_interface_speed": "80",
    "support_interface_top_layers": "3",
    "support_ironing": "0",
    "support_ironing_flow": "10%",
    "support_ironing_pattern": "rectilinear",
    "support_ironing_spacing": "0.1",
    "support_line_width": "0",
    "support_material_interface_fan_speed": [
      "-1"
    ],
    "support_max_bridge_length": "15",
    "support_max_bridges_on_pillar": "3",
    "support_max_pillar_link_distance": "10",
    "support_multi_bed_types": "0",
    "support_object_elevation": "5",
    "support_object_first_layer_gap": "0.2",
    "support_object_skip_flush": "0",
    "support_object_xy_distance": "0.35",
    "support_on_build_plate_only": "0",
    "support_parallel_printheads": "0",
    "support_pillar_connection_mode": "dynamic",
    "support_pillar_diameter": "1",
    "support_pillar_widening_factor": "0",
    "support_points_density_relative": "100",
    "support_points_minimal_distance": "1",
    "support_remove_small_overhang": "1",
    "support_small_pillar_diameter_percent": "50%",
    "support_speed": "80",
    "support_style": "default",
    "support_threshold_angle": "30",
    "support_threshold_overlap": "50%",
    "support_top_z_distance": "0.2",
    "support_type": "normal(auto)",
    "supports_enable": "1",
    "symmetric_infill_y_axis": "0",
    "temperature_vitrification": [
      "100"
    ],
    "template_custom_gcode": "",
    "textured_cool_plate_temp": [
      "40"
    ],
    "textured_cool_plate_temp_initial_layer": [
      "40"
    ],
    "textured_plate_temp": [
      "45"
    ],
    "textured_plate_temp_initial_layer": [
      "45"
    ],
    "thick_bridges": "0",
    "thick_internal_bridges": "1",
    "thumbnails": "48x48/PNG,300x300/PNG",
    "thumbnails_format": "PNG",
    "time_cost": "0",
    "time_lapse_gcode": "",
    "timelapse_type": "0",
    "tool_change_on_wipe_tower": "0",
    "top_bottom_infill_wall_overlap": "25%",
    "top_shell_layers": "4",
    "top_shell_thickness": "0.6",
    "top_solid_infill_flow_ratio": "1",
    "top_surface_acceleration": "500",
    "top_surface_density": "100%",
    "top_surface_filament_id": "0",
    "top_surface_jerk": "9",
    "top_surface_line_width": "0",
    "top_surface_pattern": "monotonicline",
    "top_surface_speed": "100",
    "travel_acceleration": "10000",
    "travel_jerk": "12",
    "travel_slope": [
      "3"
    ],
    "travel_speed": "120",
    "travel_speed_z": "0",
    "tree_support_angle_slow": "25",
    "tree_support_auto_brim": "1",
    "tree_support_branch_angle": "40",
    "tree_support_branch_angle_organic": "40",
    "tree_support_branch_diameter": "5",
    "tree_support_branch_diameter_angle": "5",
    "tree_support_branch_diameter_organic": "2",
    "tree_support_branch_distance": "5",
    "tree_support_branch_distance_organic": "1",
    "tree_support_brim_width": "3",
    "tree_support_tip_diameter": "0.8",
    "tree_support_top_rate": "30%",
    "tree_support_wall_count": "0",
    "tree_support_with_infill": "0",
    "upward_compatible_machine": "",
    "use_3mf": "0",
    "use_firmware_retraction": "0",
    "use_relative_e_distances": "1",
    "volumetric_speed_coefficients": "\"\"",
    "wall_direction": "ccw",
    "wall_distribution_count": "1",
    "wall_generator": "arachne",
    "wall_loops": "2",
    "wall_maximum_deviation": "0.025",
    "wall_maximum_resolution": "0.5",
    "wall_sequence": "inner wall/outer wall",
    "wall_transition_angle": "10",
    "wall_transition_filter_deviation": "25%",
    "wall_transition_length": "100%",
    "wipe": [
      "0"
    ],
    "wipe_before_external_loop": "0",
    "wipe_distance": [
      "1"
    ],
    "wipe_on_loops": "0",
    "wipe_speed": "80%",
    "wipe_tower_bridging": "10",
    "wipe_tower_cone_angle": "30",
    "wipe_tower_extra_flow": "100%",
    "wipe_tower_extra_rib_length": "0",
    "wipe_tower_extra_spacing": "100%",
    "wipe_tower_filament": "0",
    "wipe_tower_fillet_wall": "1",
    "wipe_tower_max_purge_speed": "90",
    "wipe_tower_no_sparse_layers": "0",
    "wipe_tower_rib_width": "8",
    "wipe_tower_rotation_angle": "0",
    "wipe_tower_type": "type2",
    "wipe_tower_wall_type": "rib",
    "wipe_tower_x": [
      "15"
    ],
    "wipe_tower_y": [
      "220"
    ],
    "wiping_volumes_extruders": [
      "70",
      "70",
      "70",
      "70",
      "70",
      "70",
      "70",
      "70",
      "70",
      "70"
    ],
    "wrapping_detection_gcode": "",
    "wrapping_detection_layers": "20",
    "wrapping_exclude_area": "",
    "xy_contour_compensation": "0",
    "xy_hole_compensation": "0",
    "z_hop": [
      "0.4"
    ],
    "z_hop_types": "Slope Lift",
    "z_offset": "0",
    "zaa_dont_alternate_fill_direction": "0",
    "zaa_enabled": "0",
    "zaa_min_z": "0.05",
    "zaa_minimize_perimeter_height": "35"
  }
}
