import { requireValue } from './errors.mjs';

export const IDENTITY_ROTATION = Object.freeze([1, 0, 0, 0, 1, 0, 0, 0, 1]);

/** Rotations are row-major 3x3; placement matrices are column-major 4x4. Units stay millimeters. */
export function poseMatrix(rotation = IDENTITY_ROTATION, mirrorX = false) {
  requireValue(
    Array.isArray(rotation) && rotation.length === 9 && rotation.every(Number.isFinite),
    'invalid_orientation',
    'Expected a finite 3x3 rotation',
  );
  for (let i = 0; i < 3; i++)
    for (let j = 0; j < 3; j++) {
      const dot =
        rotation[i * 3] * rotation[j * 3] +
        rotation[i * 3 + 1] * rotation[j * 3 + 1] +
        rotation[i * 3 + 2] * rotation[j * 3 + 2];
      requireValue(
        Math.abs(dot - Number(i === j)) < 1e-5,
        'invalid_orientation',
        'Orientation must preserve lengths',
      );
    }
  const r = rotation;
  const det =
    r[0] * (r[4] * r[8] - r[5] * r[7]) -
    r[1] * (r[3] * r[8] - r[5] * r[6]) +
    r[2] * (r[3] * r[7] - r[4] * r[6]);
  requireValue(
    Math.abs(det - 1) < 1e-5 && typeof mirrorX === 'boolean',
    'invalid_orientation',
    'Expected a proper rotation',
  );
  const s = mirrorX ? -1 : 1;
  return [s * r[0], s * r[3], s * r[6], 0, r[1], r[4], r[7], 0, r[2], r[5], r[8], 0, 0, 0, 0, 1];
}

export function multiplyRotations(a, b) {
  const result = Array(9).fill(0);
  for (let i = 0; i < 3; i++)
    for (let j = 0; j < 3; j++) for (let k = 0; k < 3; k++) result[i * 3 + j] += a[i * 3 + k] * b[k * 3 + j];
  poseMatrix(result);
  return result;
}

/** Align the selected outward face normal with the downward bed normal. */
export function rotationForFace(normal) {
  requireValue(
    Array.isArray(normal) && normal.length === 3 && normal.every(Number.isFinite),
    'invalid_orientation',
    'Invalid face normal',
  );
  const length = Math.hypot(...normal);
  requireValue(length > 1e-10, 'invalid_orientation', 'Cannot orient a degenerate face');
  const [x, y, z] = normal.map((value) => value / length);
  const dot = -z;
  if (dot > 1 - 1e-12) return [...IDENTITY_ROTATION];
  if (dot < -1 + 1e-12) return [1, 0, 0, 0, -1, 0, 0, 0, -1];
  // Rodrigues: cross(normal, -Z) = (-y,x,0).
  const a = -y,
    b = x,
    k = 1 / (1 + dot);
  return [1 - b * b * k, a * b * k, b, a * b * k, 1 - a * a * k, -a, -b, a, 1 - (a * a + b * b) * k];
}

export function extendBounds(bounds, matrix, point) {
  for (let axis = 0; axis < 3; axis++) {
    const value =
      matrix[axis] * point[0] + matrix[axis + 4] * point[1] + matrix[axis + 8] * point[2] + matrix[axis + 12];
    bounds.min[axis] = Math.min(bounds.min[axis], value);
    bounds.max[axis] = Math.max(bounds.max[axis], value);
  }
}

/** Ground and center the measured, rotated bounds without changing the selected pose. */
export function placeOnBed(matrix, bounds, bedCenter = [0, 0]) {
  const transform = [...matrix];
  transform[12] = bedCenter[0] - (bounds.min[0] + bounds.max[0]) / 2;
  transform[13] = bedCenter[1] - (bounds.min[1] + bounds.max[1]) / 2;
  transform[14] = -bounds.min[2];
  return {
    sourceToPlate: transform,
    bounds: {
      min: [bounds.min[0] + transform[12], bounds.min[1] + transform[13], 0],
      max: [bounds.max[0] + transform[12], bounds.max[1] + transform[13], bounds.max[2] - bounds.min[2]],
    },
  };
}

/** Incremental binary STL export: all triangles, transformed normals, mirrored winding, no sampling. */
export function createSTLWriter(triangleCount, transform) {
  requireValue(
    Number.isSafeInteger(triangleCount) && triangleCount > 0 && triangleCount <= 0xffffffff,
    'invalid_mesh',
    'Invalid STL triangle count',
  );
  requireValue(
    transform?.length === 16 && transform.every(Number.isFinite),
    'invalid_orientation',
    'Invalid STL transform',
  );
  const det =
    transform[0] * (transform[5] * transform[10] - transform[6] * transform[9]) -
    transform[4] * (transform[1] * transform[10] - transform[2] * transform[9]) +
    transform[8] * (transform[1] * transform[6] - transform[2] * transform[5]);
  const header = new Uint8Array(84);
  header.set(new TextEncoder().encode('Oriented STL'));
  new DataView(header.buffer).setUint32(80, triangleCount, true);
  const chunks = [header];
  let chunk,
    view,
    count = 0,
    inChunk = 0;
  return {
    addTriangle(vertices) {
      requireValue(
        count < triangleCount && vertices.length === 9 && vertices.every(Number.isFinite),
        'invalid_mesh',
        'Invalid STL triangle',
      );
      if (!chunk || inChunk === 8192) {
        if (chunk) chunks.push(chunk);
        chunk = new Uint8Array(Math.min(8192, triangleCount - count) * 50);
        view = new DataView(chunk.buffer);
        inChunk = 0;
      }
      const points = [0, 1, 2].map((index) =>
        [0, 1, 2].map(
          (axis) =>
            transform[axis] * vertices[index * 3] +
            transform[axis + 4] * vertices[index * 3 + 1] +
            transform[axis + 8] * vertices[index * 3 + 2] +
            transform[axis + 12],
        ),
      );
      if (det < 0) [points[1], points[2]] = [points[2], points[1]];
      const a = points[1].map((v, i) => v - points[0][i]),
        b = points[2].map((v, i) => v - points[0][i]);
      const normal = [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
      const length = Math.hypot(...normal);
      const numbers = [...normal.map((v) => (length ? v / length : 0)), ...points.flat()];
      numbers.forEach((value, i) => view.setFloat32(inChunk * 50 + i * 4, value, true));
      count++;
      inChunk++;
    },
    finish() {
      requireValue(count === triangleCount, 'invalid_mesh', 'STL export is incomplete');
      return new Blob([...chunks, chunk], { type: 'application/octet-stream' });
    },
  };
}
