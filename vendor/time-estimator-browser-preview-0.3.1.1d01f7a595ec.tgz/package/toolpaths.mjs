import * as THREE from 'three';
import { requireValue } from './errors.mjs';
import { PRINT_FEATURES } from './features.mjs';

// A diamond section has no coincident horizontal faces where parallel beads overlap.
const vertices = [
  0, -0.5, 0, 0, 0, 0.5, 0, 0.5, 0, 0, 0, -0.5, 1, -0.5, 0, 1, 0, 0.5, 1, 0.5, 0, 1, 0, -0.5, -1, 0, 0, 2, 0,
  0,
];
const normals = [
  0, -1, 0, 0, 0, 1, 0, 1, 0, 0, 0, -1, 0, -1, 0, 0, 0, 1, 0, 1, 0, 0, 0, -1, -1, 0, 0, 1, 0, 0,
];
const faces = [
  8, 0, 1, 8, 1, 2, 8, 2, 3, 8, 3, 0, 9, 5, 4, 9, 6, 5, 9, 7, 6, 9, 4, 7, 0, 4, 5, 0, 5, 1, 1, 5, 6, 1, 6, 2,
  2, 6, 7, 2, 7, 3, 3, 7, 4, 3, 4, 0,
];

/** Join consecutive compatible beads at one miter, including the seam of a closed loop. */
function joinAngles(segments) {
  const count = segments.length / 9,
    angles = new Float32Array(count * 2).fill(9);
  const connect = (before, after) => {
    const a = before * 9,
      b = after * 9;
    if (
      segments[a + 8] !== segments[b + 8] ||
      Math.abs(segments[a + 6] - segments[b + 6]) > 1e-6 ||
      Math.abs(segments[a + 7] - segments[b + 7]) > 1e-6 ||
      Math.hypot(
        segments[a + 3] - segments[b],
        segments[a + 4] - segments[b + 1],
        segments[a + 5] - segments[b + 2],
      ) > 1e-6
    )
      return false;
    const ax = segments[a + 3] - segments[a],
      ay = segments[a + 4] - segments[a + 1],
      bx = segments[b + 3] - segments[b],
      by = segments[b + 4] - segments[b + 1];
    if (Math.hypot(ax, ay) < 1e-8 || Math.hypot(bx, by) < 1e-8) return false;
    const angle = Math.atan2(ax * by - ay * bx, ax * bx + ay * by);
    // Avoid unbounded miters at nearly reversed paths.
    if (Math.abs(angle) > 2.6) return false;
    angles[before * 2 + 1] = angles[after * 2] = angle;
    return true;
  };
  let first = 0;
  for (let i = 1; i < count; i++)
    if (!connect(i - 1, i)) {
      if (i - 1 > first) connect(i - 1, first);
      first = i;
    }
  if (count - 1 > first) connect(count - 1, first);
  return angles;
}

/** Instanced presentation of complete native extrusion segments, in canonical millimeters. */
export function createBeadOverlay(preview, features, { chunkSegments = 65536 } = {}) {
  requireValue(
    preview?.schemaVersion === 1 &&
      preview.segments instanceof Float64Array &&
      preview.segments.length % 9 === 0,
    'invalid_preview',
    'Invalid print preview payload',
  );
  requireValue(
    Number.isSafeInteger(chunkSegments) && chunkSegments > 0 && chunkSegments <= 65536,
    'invalid_preview',
    'Invalid render chunk size',
  );
  const group = new THREE.Group();
  group.name = 'printed-toolpaths';
  const roles = new Map(PRINT_FEATURES.map((feature) => [feature.id, []]));
  const materials = [],
    batches = [];
  let disposed = false;
  const segments = preview.segments;
  for (let p = 0; p < segments.length; p += 9) {
    const [x0, y0, z0, x1, y1, z1, width, height, role] = segments.subarray(p, p + 9);
    requireValue(
      [x0, y0, z0, x1, y1, z1, width, height, role].every(Number.isFinite) &&
        width > 0 &&
        height > 0 &&
        roles.has(role),
      'invalid_preview',
      'Invalid printed segment',
    );
    requireValue(Math.abs(z1 - z0) < 1e-4, 'invalid_preview', 'Only planar extrusion paths are admitted');
    if (Math.hypot(x1 - x0, y1 - y0) > 1e-8) roles.get(role).push(p / 9);
  }
  const angles = joinAngles(segments);
  try {
    for (const feature of features) {
      const ids = roles.get(feature.id);
      if (!ids?.length) continue;
      const firstMove = { value: 0 };
      const viewportHeight = { value: 1 },
        bufferSize = new THREE.Vector2();
      const material = new THREE.MeshStandardMaterial({
        color: feature.color,
        roughness: 0.85,
        side: THREE.FrontSide,
      });
      material.userData.firstMove = firstMove;
      material.onBeforeCompile = (shader) => {
        shader.uniforms.firstMove = firstMove;
        shader.uniforms.viewportHeight = viewportHeight;
        shader.vertexShader =
          'attribute vec3 pathStart;\nattribute vec3 pathEnd;\nattribute vec2 pathSize;\nattribute vec2 pathJoins;\nattribute float pathMove;\nuniform float firstMove;\nuniform float viewportHeight;\n' +
          shader.vertexShader;
        shader.vertexShader = shader.vertexShader
          .replace(
            '#include <beginnormal_vertex>',
            `
          vec3 pathAlong = normalize(vec3(pathEnd.xy - pathStart.xy, 0.0));
          vec3 pathAcross = vec3(-pathAlong.y, pathAlong.x, 0.0);
          float startMiter = abs(pathJoins.x) < 4.0 ? tan(pathJoins.x * 0.5) : 0.0;
          float endMiter = abs(pathJoins.y) < 4.0 ? tan(pathJoins.y * 0.5) : 0.0;
          vec3 startSide = pathAcross + pathAlong * startMiter;
          vec3 endSide = pathAcross - pathAlong * endMiter;
          vec3 sideDirection = normalize(mix(startSide, endSide, clamp(position.x, 0.0, 1.0)));
          vec3 objectNormal = normal.x * pathAlong + normal.y * sideDirection + vec3(0.0, 0.0, normal.z);
          // Filter subpixel bead highlights instead of letting short caps shimmer at a distance.
          vec3 worldStart = (modelMatrix * vec4(pathStart, 1.0)).xyz;
          vec3 toEye = cameraPosition - worldStart;
          vec3 worldSide = normalize(mat3(modelMatrix) * sideDirection);
          vec3 worldUp = normalize(mat3(modelMatrix) * vec3(0.0, 0.0, 1.0));
          vec3 filteredNormal = sideDirection * dot(toEye, worldSide) + vec3(0.0, 0.0, dot(toEye, worldUp));
          float viewDepth = isOrthographic ? 1.0 : abs((modelViewMatrix * vec4(pathStart, 1.0)).z);
          float pixelsPerBead = pathSize.y * length(modelMatrix[2].xyz) * abs(projectionMatrix[1][1]) * viewportHeight / (2.0 * max(viewDepth, 0.001));
          if (length(filteredNormal) > 0.0001) objectNormal = mix(normalize(filteredNormal), objectNormal, smoothstep(0.7, 2.0, pixelsPerBead));
        `,
          )
          .replace(
            '#include <begin_vertex>',
            `
          vec3 line = pathEnd - pathStart;
          vec3 along = vec3(normalize(line.xy), 0.0);
          vec3 across = vec3(-along.y, along.x, 0.0);
          float startCap = abs(pathJoins.x) < 4.0 ? 0.0 : pathSize.x * 0.5;
          float endCap = abs(pathJoins.y) < 4.0 ? 0.0 : pathSize.x * 0.5;
          float distanceAlong = position.x < 0.0 ? -startCap : position.x > 1.0 ? length(line.xy) + endCap : position.x * length(line.xy);
          vec3 miterSide = mix(startSide, endSide, clamp(position.x, 0.0, 1.0));
          vec3 transformed = pathStart + along * distanceAlong
            + miterSide * (position.y * pathSize.x) + vec3(0.0, 0.0, (position.z - 0.5) * pathSize.y);
        `,
          )
          .replace(
            '#include <project_vertex>',
            '#include <project_vertex>\nif (pathMove < firstMove) gl_Position = vec4(2.0, 2.0, 2.0, 1.0);',
          );
      };
      material.customProgramCacheKey = () => 'beveled-print-path-v4';
      materials.push(material);
      for (let first = 0; first < ids.length; first += chunkSegments) {
        const count = Math.min(chunkSegments, ids.length - first);
        const starts = new Float32Array(count * 3),
          ends = new Float32Array(count * 3),
          sizes = new Float32Array(count * 2),
          joins = new Float32Array(count * 2);
        const segmentIds = new Uint32Array(count),
          moves = new Float32Array(count),
          box = new THREE.Box3();
        for (let i = 0; i < count; i++) {
          const id = ids[first + i],
            p = id * 9;
          starts.set(segments.subarray(p, p + 3), i * 3);
          ends.set(segments.subarray(p + 3, p + 6), i * 3);
          sizes.set(segments.subarray(p + 6, p + 8), i * 2);
          joins.set(angles.subarray(id * 2, id * 2 + 2), i * 2);
          segmentIds[i] = moves[i] = id;
          const w = segments[p + 6] * 2.5,
            h = segments[p + 7];
          box.expandByPoint(
            new THREE.Vector3(
              Math.min(segments[p], segments[p + 3]) - w,
              Math.min(segments[p + 1], segments[p + 4]) - w,
              segments[p + 2] - h,
            ),
          );
          box.expandByPoint(
            new THREE.Vector3(
              Math.max(segments[p], segments[p + 3]) + w,
              Math.max(segments[p + 1], segments[p + 4]) + w,
              segments[p + 2],
            ),
          );
        }
        const geometry = new THREE.InstancedBufferGeometry();
        geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
        geometry.setIndex(faces);
        geometry.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
        geometry.setAttribute('pathStart', new THREE.InstancedBufferAttribute(starts, 3));
        geometry.setAttribute('pathEnd', new THREE.InstancedBufferAttribute(ends, 3));
        geometry.setAttribute('pathSize', new THREE.InstancedBufferAttribute(sizes, 2));
        geometry.setAttribute('pathJoins', new THREE.InstancedBufferAttribute(joins, 2));
        geometry.setAttribute('pathMove', new THREE.InstancedBufferAttribute(moves, 1));
        geometry.instanceCount = count;
        geometry.boundingBox = box;
        geometry.boundingSphere = box.getBoundingSphere(new THREE.Sphere());
        const mesh = new THREE.Mesh(geometry, material);
        mesh.onBeforeRender = (renderer) => {
          viewportHeight.value = renderer.getDrawingBufferSize(bufferSize).y;
        };
        mesh.name = feature.name;
        group.add(mesh);
        batches.push({ mesh, role: feature.id, segmentIds, count });
      }
    }
  } catch (error) {
    for (const { mesh } of batches) mesh.geometry.dispose();
    for (const material of materials) material.dispose();
    throw error;
  }
  function setLayerRange(minZ = -Infinity, maxZ = Infinity) {
    requireValue(
      (minZ === -Infinity || Number.isFinite(minZ)) &&
        (maxZ === Infinity || Number.isFinite(maxZ)) &&
        minZ <= maxZ,
      'invalid_preview',
      'Invalid layer range',
    );
    let sceneRoot = group;
    while (sceneRoot.parent) sceneRoot = sceneRoot.parent;
    sceneRoot.updateMatrixWorld(true);
    const planes = [];
    if (maxZ !== Infinity)
      planes.push(new THREE.Plane(new THREE.Vector3(0, 0, -1), maxZ).applyMatrix4(group.matrixWorld));
    if (minZ !== -Infinity)
      planes.push(new THREE.Plane(new THREE.Vector3(0, 0, 1), -minZ).applyMatrix4(group.matrixWorld));
    for (const material of materials) material.clippingPlanes = planes;
  }
  function setMoveRange(start = 0, end = Infinity) {
    requireValue(
      Number.isSafeInteger(start) &&
        start >= 0 &&
        (end === Infinity || (Number.isSafeInteger(end) && end >= start)),
      'invalid_preview',
      'Invalid move range',
    );
    for (const material of materials) material.userData.firstMove.value = start;
    for (const batch of batches) {
      let low = 0,
        high = batch.count;
      while (low < high) {
        const mid = (low + high) >>> 1;
        if (batch.segmentIds[mid] < end) low = mid + 1;
        else high = mid;
      }
      batch.mesh.geometry.instanceCount = low;
    }
  }
  return {
    group,
    setLayerRange,
    setMoveRange,
    setHeight(printZ = Infinity) {
      setLayerRange(-Infinity, printZ);
    },
    setEndMove(end = Infinity) {
      setMoveRange(0, end);
    },
    setFeatureVisible(role, visible) {
      for (const batch of batches) if (batch.role === role) batch.mesh.visible = Boolean(visible);
    },
    setVisible(visible) {
      group.visible = Boolean(visible);
    },
    dispose() {
      if (disposed) return;
      disposed = true;
      group.removeFromParent();
      for (const { mesh } of batches) mesh.geometry.dispose();
      for (const material of materials) material.dispose();
      group.clear();
    },
  };
}
