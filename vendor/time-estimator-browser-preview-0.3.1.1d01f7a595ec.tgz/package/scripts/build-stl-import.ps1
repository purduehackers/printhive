param(
    [Parameter(Mandatory = $true)][string]$EmsdkRoot,
    [string]$BuildDirectory,
    [string]$EigenIncludeDirectory
)
$ErrorActionPreference = 'Stop'
$repoRoot = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
$sdkRoot = (Resolve-Path $EmsdkRoot).Path
if (-not $BuildDirectory) { $BuildDirectory = Join-Path $repoRoot 'build/browser-repair' }
$toolchain = Join-Path $sdkRoot 'upstream/emscripten/cmake/Modules/Platform/Emscripten.cmake'
$compilerName = if ($IsWindows) { 'emcc.exe' } else { 'emcc' }
$compiler = Join-Path $sdkRoot "upstream/emscripten/$compilerName"
$version = & $compiler --version
if ($LASTEXITCODE -ne 0 -or $version[0] -notmatch '6\.0\.13') { throw 'Use the pinned Emscripten 6.0.13 SDK.' }
$arguments = @('-S', (Join-Path $repoRoot 'browser/repair'), '-B', $BuildDirectory, '-G', 'Ninja',
    '-DCMAKE_BUILD_TYPE=Release', "-DCMAKE_TOOLCHAIN_FILE=$toolchain")
if ($EigenIncludeDirectory) {
    $EigenIncludeDirectory = (Resolve-Path $EigenIncludeDirectory).Path
    $arguments += "-DEIGEN_INCLUDE_DIR=$EigenIncludeDirectory"
}
& cmake @arguments
if ($LASTEXITCODE -ne 0) { throw 'Browser importer configuration failed.' }
& cmake --build $BuildDirectory --parallel 2
if ($LASTEXITCODE -ne 0) { throw 'Browser importer compilation failed.' }
$destination = Join-Path $repoRoot 'browser/repair'
Copy-Item -LiteralPath (Join-Path $BuildDirectory 'stl-import.mjs') -Destination $destination
$licenses = Join-Path $destination 'licenses'
New-Item -ItemType Directory -Force -Path $licenses | Out-Null
Copy-Item (Join-Path $repoRoot 'third_party/orca_admesh/LICENSE.*') $licenses
if (-not $EigenIncludeDirectory) { $EigenIncludeDirectory = Join-Path $BuildDirectory '_deps/browser_eigen-src' }
Copy-Item (Join-Path $EigenIncludeDirectory 'COPYING.*') $licenses
$runtimeNotices = @{
    'LICENSE' = 'Emscripten-LICENSE.txt'
    'system/lib/libcxx/LICENSE.TXT' = 'libcxx-LICENSE.txt'
    'system/lib/libcxxabi/LICENSE.TXT' = 'libcxxabi-LICENSE.txt'
    'system/lib/compiler-rt/LICENSE.TXT' = 'compiler-rt-LICENSE.txt'
    'system/lib/libc/musl/COPYRIGHT' = 'musl-COPYRIGHT.txt'
    'system/lib/libunwind/LICENSE.TXT' = 'libunwind-LICENSE.txt'
    'system/lib/llvm-libc/LICENSE.TXT' = 'llvm-libc-LICENSE.txt'
    'system/lib/mimalloc/LICENSE' = 'mimalloc-LICENSE.txt'
}
foreach ($notice in $runtimeNotices.GetEnumerator()) {
    Copy-Item -LiteralPath (Join-Path $sdkRoot ('upstream/emscripten/' + $notice.Key)) -Destination (Join-Path $licenses $notice.Value)
}
$sources = [ordered]@{}
$inputs = @('native/stl_import.cpp','browser/repair/bridge.cpp','browser/repair/CMakeLists.txt')
$inputs += Get-ChildItem (Join-Path $repoRoot 'third_party/orca_admesh') -File | ForEach-Object { 'third_party/orca_admesh/' + $_.Name }
$inputs += Get-ChildItem (Join-Path $repoRoot 'native/stl_import_compat') -File -Recurse | ForEach-Object { [IO.Path]::GetRelativePath($repoRoot,$_.FullName).Replace('\','/') }
foreach ($inputFile in $inputs) { $sources[$inputFile] = (Get-FileHash -LiteralPath (Join-Path $repoRoot $inputFile) -Algorithm SHA256).Hash.ToLowerInvariant() }
$manifest = [ordered]@{
    schemaVersion = 1
    emscripten = '6.0.13'
    orcaSourceRevision = '8500fcdccaa10b5099ac20d252af3a7c560046f1'
    eigen = '5.0.1'
    moduleSha256 = (Get-FileHash -LiteralPath (Join-Path $destination 'stl-import.mjs') -Algorithm SHA256).Hash.ToLowerInvariant()
    sources = $sources
}
[IO.File]::WriteAllText((Join-Path $destination 'build.json'), ($manifest | ConvertTo-Json -Depth 4) + "`n", [Text.UTF8Encoding]::new($false))
