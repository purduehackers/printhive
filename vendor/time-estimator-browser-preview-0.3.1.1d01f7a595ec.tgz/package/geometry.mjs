import { PreviewError, requireValue, limitsFor } from './errors.mjs';
import { poseMatrix, extendBounds, placeOnBed } from './pose.mjs';

/** STL repeats vertices per triangle. Restore exact shared vertices without changing geometry. */
export function indexTriangleSoup(positions) {
  requireValue(
    positions instanceof Float32Array && positions.length % 9 === 0 && positions.length > 0,
    'invalid_mesh',
    'Expected complete STL triangles',
  );
  const vertices = [],
    indices = new Uint32Array(positions.length / 3),
    known = new Map();
  for (let offset = 0; offset < positions.length; offset += 3) {
    const x = positions[offset],
      y = positions[offset + 1],
      z = positions[offset + 2];
    requireValue(
      Number.isFinite(x) && Number.isFinite(y) && Number.isFinite(z),
      'invalid_mesh',
      'Nonfinite vertex',
    );
    const key = `${x},${y},${z}`;
    let index = known.get(key);
    if (index === undefined) {
      index = vertices.length / 3;
      known.set(key, index);
      vertices.push(x, y, z);
    }
    indices[offset / 3] = index;
  }
  return { positions: new Float32Array(vertices), indices };
}

/** Validate a complete mesh and place its XY center on the bed, with its bottom at Z=0. */
export function prepareMesh(mesh, { mirrorX = false, rotation, bedCenter, limits } = {}) {
  const budget = limitsFor(limits);
  requireValue(typeof mirrorX === 'boolean', 'invalid_mesh', 'mirrorX must be a boolean');
  requireValue(
    Array.isArray(bedCenter) && bedCenter.length === 2 && bedCenter.every(Number.isFinite),
    'invalid_configuration',
    'An explicit bed center in millimeters is required',
  );
  let positions = mesh?.positions;
  requireValue(
    positions instanceof Float32Array && positions.length >= 9 && positions.length % 3 === 0,
    'invalid_mesh',
    'positions must contain complete XYZ vertices',
  );
  let count = positions.length / 3;
  let indices = mesh.indices;
  if (indices === undefined) {
    requireValue(
      count % 3 === 0 && count / 3 <= budget.maxTriangles,
      'mesh_limit',
      'The complete mesh exceeds the browser triangle limit',
    );
    ({ positions, indices } = indexTriangleSoup(positions));
    count = positions.length / 3;
  }
  requireValue(
    indices instanceof Uint32Array && indices.length >= 3 && indices.length % 3 === 0,
    'invalid_mesh',
    'indices must contain complete triangle triples',
  );
  requireValue(
    indices.length / 3 <= budget.maxTriangles && count <= budget.maxTriangles * 3,
    'mesh_limit',
    'The complete mesh exceeds the browser triangle limit',
  );
  const min = [Infinity, Infinity, Infinity],
    max = [-Infinity, -Infinity, -Infinity];
  const linear = poseMatrix(rotation, mirrorX);
  const rotated = { min: [Infinity, Infinity, Infinity], max: [-Infinity, -Infinity, -Infinity] };
  for (let i = 0; i < positions.length; ++i) {
    const value = positions[i];
    requireValue(Number.isFinite(value), 'invalid_mesh', 'Mesh coordinates must be finite');
  }
  // Only referenced vertices determine the physical bounds.
  for (const index of indices) {
    requireValue(index < count, 'invalid_mesh', 'Triangle index is out of range');
    for (let axis = 0; axis < 3; ++axis) {
      min[axis] = Math.min(min[axis], positions[index * 3 + axis]);
      max[axis] = Math.max(max[axis], positions[index * 3 + axis]);
    }
    extendBounds(rotated, linear, positions.subarray(index * 3, index * 3 + 3));
  }
  requireValue(
    max.every((value, i) => value > min[i]),
    'invalid_mesh',
    'A solid three-dimensional mesh is required',
  );
  const { sourceToPlate: transform, bounds: canonicalBounds } = placeOnBed(linear, rotated, bedCenter);
  // A reflection changes handedness. Reverse each face before passing it to the C++ engine.
  if (mirrorX) {
    indices = indices.slice();
    for (let i = 0; i < indices.length; i += 3)
      [indices[i + 1], indices[i + 2]] = [indices[i + 2], indices[i + 1]];
  }
  return {
    positions,
    indices,
    sourceToPlate: transform,
    sourceBounds: { min, max },
    bounds: canonicalBounds,
  };
}

export function displayTransform(bounds) {
  const { min, max } = bounds;
  requireValue(
    min?.length === 3 && max?.length === 3 && [...min, ...max].every(Number.isFinite),
    'invalid_bounds',
    'Finite XYZ bounds are required',
  );
  const center = min.map((value, i) => (value + max[i]) / 2);
  const extent = Math.max(...max.map((value, i) => value - min[i]));
  requireValue(
    extent > 0 && max.every((value, i) => value >= min[i]),
    'invalid_bounds',
    'Bounds are inverted or empty',
  );
  const scale = 2 / extent;
  // Rx(-pi/2) * uniform scale * translate(-center), column-major.
  return [
    scale,
    0,
    0,
    0,
    0,
    0,
    -scale,
    0,
    0,
    scale,
    0,
    0,
    -center[0] * scale,
    -center[2] * scale,
    center[1] * scale,
    1,
  ];
}

export function applyTransform(matrix, point) {
  return [0, 1, 2].map(
    (i) => matrix[i] * point[0] + matrix[i + 4] * point[1] + matrix[i + 8] * point[2] + matrix[i + 12],
  );
}

export function bedCenterFor(configuration) {
  const area = configuration.printable_area;
  requireValue(
    Array.isArray(area) && area.length >= 3,
    'invalid_configuration',
    'printable_area is required',
  );
  const points = area.map((point) => {
    const values = typeof point === 'string' ? point.split('x').map(Number) : point;
    requireValue(
      Array.isArray(values) && values.length === 2 && values.every(Number.isFinite),
      'invalid_configuration',
      'Unsupported printable_area coordinates',
    );
    return values;
  });
  // This first adapter admits rectangular beds only; a bounding-box center can lie outside a concave bed.
  const xs = [...new Set(points.map((point) => point[0]))],
    ys = [...new Set(points.map((point) => point[1]))];
  requireValue(
    points.length === 4 &&
      xs.length === 2 &&
      ys.length === 2 &&
      new Set(points.map((point) => point.join(','))).size === 4 &&
      points.every(
        (point, i) => (point[0] === points[(i + 1) % 4][0]) !== (point[1] === points[(i + 1) % 4][1]),
      ),
    'unsupported_bed',
    'This preview adapter currently requires a rectangular bed',
  );
  return [(Math.min(...xs) + Math.max(...xs)) / 2, (Math.min(...ys) + Math.max(...ys)) / 2];
}

export { PreviewError };
