import * as THREE from 'three';
import { ConvexGeometry } from 'three/addons/geometries/ConvexGeometry.js';
import { createBeadOverlay } from './toolpaths.mjs';
import { PRINT_FEATURES } from './features.mjs';
import { requireValue } from './errors.mjs';
import { indexTriangleSoup } from './geometry.mjs';

/** Convex-hull faces offer stable placements instead of concave/internal triangles. */
export function createPlacementHull(positions) {
  requireValue(
    positions instanceof Float32Array && positions.length % 3 === 0,
    'invalid_mesh',
    'Invalid hull mesh',
  );
  positions = indexTriangleSoup(positions).positions;
  const points = [];
  for (let i = 0; i < positions.length; i += 3)
    points.push(new THREE.Vector3(positions[i], positions[i + 1], positions[i + 2]));
  return new ConvexGeometry(points);
}
export function createToolpathOverlay(preview, options = {}) {
  return createBeadOverlay(preview, PRINT_FEATURES, options);
}
export function createSupportOverlay(
  preview,
  { baseColor = '#427f9e', interfaceColor = '#bc7031', ...options } = {},
) {
  return createBeadOverlay(
    preview,
    PRINT_FEATURES.filter((feature) => feature.category === 'supports').map((feature) => ({
      ...feature,
      color: feature.id === 1 ? baseColor : feature.id === 2 ? interfaceColor : feature.color,
    })),
    options,
  );
}
