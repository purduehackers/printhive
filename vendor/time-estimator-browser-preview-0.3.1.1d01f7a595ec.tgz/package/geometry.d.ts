import type { Mesh, Bounds, Limits } from './index.js';
export function indexTriangleSoup(positions: Float32Array): Mesh & {indices:Uint32Array};
export function prepareMesh(mesh: Mesh, options: { mirrorX?: boolean; rotation?: number[]; bedCenter: number[]; limits?: Partial<Limits> }): Mesh & { indices: Uint32Array; sourceToPlate: number[]; sourceBounds: Bounds; bounds: Bounds };
export function displayTransform(bounds: Bounds): number[];
export function applyTransform(matrix: number[], point: ArrayLike<number>): number[];
export function bedCenterFor(configuration: Record<string, unknown>): number[];
