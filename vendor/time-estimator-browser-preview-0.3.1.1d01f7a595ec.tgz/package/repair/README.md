# Browser STL import

This WebAssembly module builds the existing C++17 Orca-compatible STL import program for
the browser. It runs Orca 2.4.2's retained ADMesh import sequence, including shared vertices,
nearby-edge repair and normal correction. It does not fill holes; Orca intentionally leaves
that to slice-space gap closing. Original uploaded geometry is transformed separately: repair
is used for slicing and automatic orientation, and does not silently rewrite the submission.

Source: Orca `8500fcdccaa10b5099ac20d252af3a7c560046f1`, Eigen 5.0.1 and the existing
`native/stl_import.cpp` entry point. The browser build links neither the native estimator SDK
nor its server worker. Its generated single-file module embeds WASM and needs no interpreter
or runtime file download. License texts are under `licenses/`.

Build from the source checkout with Emscripten 6.0.13, CMake and Ninja:

```sh
emcmake cmake -S browser/repair -B build/browser-repair -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build/browser-repair --parallel 2
```

Copy the resulting `stl-import.mjs` here when updating the package; record its SHA-256 and
compiler/source identities in `build.json`. The package includes the prebuilt browser module.
No production/server build changes or toolchain installation are required by a consumer.

On the maintained PowerShell checkout, `browser/scripts/build-stl-import.ps1 -EmsdkRoot PATH`
performs those steps and refreshes the dependency notices and source/output hash inventory.
An existing Eigen source directory can be selected with `-EigenIncludeDirectory PATH`.

Validation includes damaged normals/winding, shared vertices, invalid-input recovery and actual
browser-worker slicing/orientation. On the maintained Windows checkout, the WASM and native
import programs produced byte-identical mesh output for two box fixtures and a local 1,644-face
STL. This qualifies that import path on those fixtures, not every desktop slicing feature.
