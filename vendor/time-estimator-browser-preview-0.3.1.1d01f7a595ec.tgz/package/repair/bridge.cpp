// Reuse the native import program as a function, without a CLI process-exit side effect.
#define main native_stl_main
#include "../../native/stl_import.cpp"
#undef main

static_assert(EIGEN_MAJOR_VERSION == 5 && EIGEN_MINOR_VERSION == 0 && EIGEN_PATCH_VERSION == 1,
              "The browser importer requires the pinned Eigen 5.0.1 headers");

extern "C" int browser_import_stl() {
    char program[] = "stl-import";
    char source[] = "/input.stl";
    char destination[] = "/mesh.bin";
    char *arguments[] = {program, source, destination};
    return native_stl_main(3, arguments);
}
