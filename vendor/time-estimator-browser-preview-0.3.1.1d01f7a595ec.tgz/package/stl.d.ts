import type { Mesh, Limits } from './index.js';
export function readSTL(file: Blob, options?: {limits?: Partial<Limits>}): Promise<Mesh & {indices:Uint32Array;importer:{kind:'orca_stl_repair';sourceRevision:string}}>;
