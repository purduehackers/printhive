import createImporter from './repair/stl-import.mjs';
import { PreviewError, limitsFor, requireValue } from './errors.mjs';

/** Decode and repair STL using Orca's C++ import path. Call in a disposable worker. */
export async function readSTL(file, { limits } = {}) {
  const budget = limitsFor(limits);
  requireValue(
    file instanceof Blob && file.size > 0 && file.size <= 500 * 1024 * 1024,
    'mesh_limit',
    'Choose an STL up to 500 MiB.',
  );
  const messages = [];
  let module;
  try {
    module = await createImporter({
      noInitialRun: true,
      print() {},
      printErr(message) {
        messages.push(String(message).slice(0, 300));
        if (messages.length > 12) messages.shift();
      },
    });
    module.FS.writeFile('/input.stl', new Uint8Array(await file.arrayBuffer()), { canOwn: true });
    const status = module._browser_import_stl();
    if (status)
      throw new PreviewError('import_failed', 'Orca could not repair this STL into a printable mesh.', {
        messages,
        status,
      });
    const bytes = module.FS.readFile('/mesh.bin');
    const view = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    requireValue(
      bytes.length >= 20 &&
        new TextDecoder().decode(bytes.subarray(0, 8)) === 'TESTLM01' &&
        view.getUint32(8, true) === 1,
      'invalid_runtime_output',
      'Invalid STL import result',
    );
    const vertexCount = view.getUint32(12, true),
      triangleCount = view.getUint32(16, true);
    requireValue(
      vertexCount > 0 &&
        triangleCount > 0 &&
        triangleCount <= budget.maxTriangles &&
        vertexCount <= budget.maxTriangles * 3,
      'mesh_limit',
      'This model exceeds the available browser memory budget.',
    );
    requireValue(
      bytes.length === 20 + vertexCount * 12 + triangleCount * 12,
      'invalid_runtime_output',
      'Incomplete STL import result',
    );
    return {
      positions: new Float32Array(bytes.buffer, bytes.byteOffset + 20, vertexCount * 3),
      indices: new Uint32Array(bytes.buffer, bytes.byteOffset + 20 + vertexCount * 12, triangleCount * 3),
      importer: { kind: 'orca_stl_repair', sourceRevision: '8500fcdccaa10b5099ac20d252af3a7c560046f1' },
    };
  } catch (error) {
    if (/out of memory|bad_alloc|cannot enlarge memory/i.test(String(error) + messages.join(' '))) {
      throw new PreviewError('out_of_memory', 'Not enough browser memory to import this STL.', { messages });
    }
    if (error instanceof PreviewError) throw error;
    throw new PreviewError('import_failed', 'The browser could not import this STL.', {
      messages,
      reason: String(error),
    });
  } finally {
    try {
      module?.FS.unlink('/input.stl');
    } catch {}
    try {
      module?.FS.unlink('/mesh.bin');
    } catch {}
  }
}
