import { PreviewError, requireValue, limitsFor } from './errors.mjs';
import { prepareMesh, bedCenterFor, applyTransform } from './geometry.mjs';
import { readSupportPaths, readPrintPaths } from './gcode.mjs';
import { multiplyRotations, IDENTITY_ROTATION, poseMatrix } from './pose.mjs';

const encoder = new TextEncoder(),
  decoder = new TextDecoder();
export async function digest(bytes) {
  // Ordinary HTTP hosts do not expose subtle, even though module workers and WASM work.
  // Keep integrity verification enabled there with the same SHA-256 algorithm.
  let hash;
  if (globalThis.crypto?.subtle?.digest) {
    hash = new Uint8Array(await globalThis.crypto.subtle.digest('SHA-256', bytes));
  } else {
    const { sha256 } = await import('./vendor/noble-hashes/sha2.js');
    const input = ArrayBuffer.isView(bytes)
      ? new Uint8Array(bytes.buffer, bytes.byteOffset, bytes.byteLength)
      : new Uint8Array(bytes);
    hash = sha256(input);
  }
  return [...hash].map((value) => value.toString(16).padStart(2, '0')).join('');
}
function sorted(value) {
  if (Array.isArray(value)) return value.map(sorted);
  if (value && typeof value === 'object')
    return Object.fromEntries(
      Object.keys(value)
        .sort()
        .map((key) => [key, sorted(value[key])]),
    );
  return value;
}
async function assetBytes(asset, base) {
  requireValue(
    asset && typeof asset.file === 'string' && /^[a-f0-9]{64}$/.test(asset.sha256),
    'invalid_runtime',
    'Every engine asset needs a path and SHA-256',
  );
  const url = new URL(asset.file, base);
  requireValue(
    ['http:', 'https:'].includes(url.protocol) && url.origin === new URL(base).origin,
    'invalid_runtime',
    'Engine assets must share the manifest origin',
  );
  const response = await fetch(url, { credentials: 'same-origin' });
  requireValue(response.ok, 'runtime_download', `Could not download engine asset (${response.status})`);
  const bytes = await response.arrayBuffer();
  requireValue(
    bytes.byteLength <= 128 * 1024 * 1024 && (await digest(bytes)) === asset.sha256,
    'runtime_integrity',
    'Browser engine asset checksum did not match',
  );
  return bytes;
}

/** Load a separately supplied, checksummed serial Orca ABI-1 runtime. No native/server dependency. */
export async function loadOrcaRuntime(manifestUrl, onProgress = () => {}) {
  const url = new URL(manifestUrl, globalThis.location?.href);
  const response = await fetch(url, { credentials: 'same-origin' });
  requireValue(response.ok, 'runtime_download', `Could not load engine manifest (${response.status})`);
  const manifest = await response.json();
  requireValue(
    manifest.schemaVersion === 1 &&
      manifest.kind === 'orca-cubby-serial' &&
      manifest.engine?.version === '2.4.2' &&
      manifest.engine?.bridge === 1,
    'invalid_runtime',
    'Unsupported browser engine manifest',
  );
  onProgress({ stage: 'loading_engine', percent: 0, message: 'Loading local support engine' });
  const [moduleBytes, wasm, data] = await Promise.all([
    assetBytes(manifest.module, url),
    assetBytes(manifest.wasm, url),
    assetBytes(manifest.data, url),
  ]);
  const moduleUrl = URL.createObjectURL(new Blob([moduleBytes], { type: 'text/javascript' }));
  let factory;
  try {
    factory = (await import(/* @vite-ignore */ moduleUrl)).default;
  } finally {
    URL.revokeObjectURL(moduleUrl);
  }
  const module = await factory({
    wasmBinary: new Uint8Array(wasm),
    getPreloadedPackage: () => data,
    locateFile: (file) => new URL(file, url).href,
    print() {},
    printErr() {},
    csProgress: (percent, message) => onProgress({ stage: 'generating', percent, message }),
  });
  const version = JSON.parse(module.UTF8ToString(module._cs_version(), 1024));
  requireValue(
    version.engine === 'orca' && version.version === manifest.engine.version && version.bridge === 1,
    'runtime_mismatch',
    'The loaded engine does not match the declared ABI/version',
  );
  return new OrcaRuntime(module, manifest, onProgress);
}

export class OrcaRuntime {
  constructor(module, manifest, onProgress = () => {}) {
    this.module = module;
    this.manifest = manifest;
    this.onProgress = onProgress;
  }

  /** Use Orca's AutoOrienter and return an absolute source-space rotation. */
  async orient(request, mesh) {
    const prepared = prepareMesh(mesh, {
      rotation: request.rotation,
      mirrorX: request.mirrorX,
      bedCenter: [0, 0],
      limits: request.limits,
    });
    const module = this.module;
    requireValue(
      typeof module._cs_orient === 'function',
      'unsupported_runtime',
      'This engine has no automatic orientation',
    );
    const blob = new Uint8Array(prepared.positions.byteLength + prepared.indices.byteLength);
    const centered = new Float32Array(prepared.positions.length);
    for (let offset = 0; offset < centered.length; offset += 3)
      centered.set(
        applyTransform(prepared.sourceToPlate, prepared.positions.subarray(offset, offset + 3)),
        offset,
      );
    blob.set(new Uint8Array(centered.buffer));
    blob.set(
      new Uint8Array(prepared.indices.buffer, prepared.indices.byteOffset, prepared.indices.byteLength),
      prepared.positions.byteLength,
    );
    const job = encoder.encode(
      JSON.stringify({
        objects: [
          {
            name: 'orientation',
            vertexOffset: 0,
            vertexCount: prepared.positions.length / 3,
            indexOffset: prepared.positions.byteLength,
            triangleCount: prepared.indices.length / 3,
            transform: [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1],
          },
        ],
      }),
    );
    const pointers = [];
    let output = 0;
    const allocate = (size) => {
      const pointer = module._malloc(size);
      requireValue(pointer, 'out_of_memory', 'Not enough browser memory');
      pointers.push(pointer);
      return pointer;
    };
    try {
      const a = allocate(job.length),
        b = allocate(blob.length),
        out = allocate(8);
      module.HEAPU8.set(job, a);
      module.HEAPU8.set(blob, b);
      module.HEAPU8.fill(0, out, out + 8);
      const rc = module._cs_orient(a, job.length, b, blob.length, out, out + 4);
      const [pointer, length] = new Uint32Array(module.HEAPU8.buffer, out, 2).slice();
      output = pointer;
      requireValue(
        length > 0 && length < 65536 && pointer + length <= module.HEAPU8.length,
        'invalid_runtime_output',
        'Invalid orientation response',
      );
      const report = JSON.parse(decoder.decode(module.HEAPU8.subarray(pointer, pointer + length)));
      requireValue(
        rc === 0 && report.ok,
        'orientation_failed',
        report.error || 'Automatic orientation failed',
      );
      poseMatrix(report.rotation);
      return {
        rotation: multiplyRotations(report.rotation, request.rotation ?? IDENTITY_ROTATION),
        basis: 'orca_auto_orient',
      };
    } finally {
      if (output) module._cs_free(output);
      for (const pointer of pointers) module._free(pointer);
    }
  }

  async generate(request, mesh) {
    const limits = limitsFor(request.limits);
    const view = request.view ?? 'supports';
    requireValue(view === 'supports' || view === 'print', 'invalid_request', 'Unknown preview view');
    const profile = request.profile;
    requireValue(
      profile &&
        typeof profile.id === 'string' &&
        profile.id.length > 0 &&
        typeof profile.label === 'string' &&
        profile.configuration &&
        !Array.isArray(profile.configuration),
      'needs_configuration',
      'An explicitly identified printer/process/filament preview profile is required',
    );
    requireValue(
      request.support === 'tree' || request.support === 'normal' || request.support === 'none',
      'needs_configuration',
      'Choose an explicit support scenario',
    );
    const config = structuredClone(profile.configuration);
    for (const name of [
      'nozzle_diameter',
      'filament_diameter',
      'printable_area',
      'printable_height',
      'layer_height',
    ]) {
      requireValue(name in config, 'needs_configuration', `Preview profile is missing ${name}`);
    }
    requireValue(
      Array.isArray(config.nozzle_diameter) &&
        config.nozzle_diameter.length === 1 &&
        Array.isArray(config.filament_diameter) &&
        config.filament_diameter.length === 1,
      'unsupported_configuration',
      'The browser adapter currently admits one nozzle and one filament',
    );
    requireValue(
      !('inherits' in config),
      'unresolved_profile',
      'Resolve preset inheritance before sending a profile',
    );
    requireValue(JSON.stringify(config).length <= 2_000_000, 'invalid_configuration', 'Profile is too large');
    if (request.layerHeight !== undefined) {
      requireValue(
        Number.isFinite(request.layerHeight) && request.layerHeight > 0 && request.layerHeight <= 1,
        'invalid_configuration',
        'Invalid physical layer height',
      );
      config.layer_height = String(request.layerHeight);
    }
    if (request.infill !== undefined) {
      requireValue(
        Number.isFinite(request.infill) && request.infill >= 0 && request.infill <= 100,
        'invalid_configuration',
        'Invalid infill percentage',
      );
      config.sparse_infill_density = `${request.infill}%`;
    }
    config.enable_support = request.support === 'none' ? '0' : '1';
    config.support_type = request.support === 'tree' ? 'tree(auto)' : 'normal(auto)';
    requireValue(
      !config.support_style || config.support_style === 'default',
      'unsupported_configuration',
      'This runtime is currently qualified only for the default support style',
    );
    const prepared = prepareMesh(mesh, {
      mirrorX: request.mirrorX ?? false,
      rotation: request.rotation,
      bedCenter: bedCenterFor(config),
      limits,
    });
    let virtualBedExpanded = false;
    if (request.fitBed === true) {
      const area = config.printable_area.map((point) =>
        typeof point === 'string' ? point.split('x').map(Number) : point,
      );
      const oldCenter = bedCenterFor(config);
      const dimensions = prepared.bounds.max.map((value, i) => value - prepared.bounds.min[i]);
      const width = Math.max(...area.map((point) => point[0])) - Math.min(...area.map((point) => point[0]));
      const depth = Math.max(...area.map((point) => point[1])) - Math.min(...area.map((point) => point[1]));
      const x = Math.max(width, Math.ceil(dimensions[0] + 10)),
        y = Math.max(depth, Math.ceil(dimensions[1] + 10));
      const height = Math.max(Number(config.printable_height), Math.ceil(dimensions[2] + 5));
      virtualBedExpanded = x !== width || y !== depth || height !== Number(config.printable_height);
      if (virtualBedExpanded) {
        config.printable_area = ['0x0', `${x}x0`, `${x}x${y}`, `0x${y}`];
        config.printable_height = String(height);
        for (let axis = 0; axis < 2; axis++) {
          const shift = [x / 2, y / 2][axis] - oldCenter[axis];
          prepared.sourceToPlate[12 + axis] += shift;
          prepared.bounds.min[axis] += shift;
          prepared.bounds.max[axis] += shift;
        }
      }
    }
    const bytes = new Uint8Array(prepared.positions.byteLength + prepared.indices.byteLength);
    bytes.set(
      new Uint8Array(prepared.positions.buffer, prepared.positions.byteOffset, prepared.positions.byteLength),
    );
    bytes.set(
      new Uint8Array(prepared.indices.buffer, prepared.indices.byteOffset, prepared.indices.byteLength),
      prepared.positions.byteLength,
    );
    const provenance = {
      engine: this.manifest.engine,
      runtimeSha256: this.manifest.wasm.sha256,
      sourceRevision: this.manifest.sourceRevision ?? null,
      profileId: profile.id,
      importer: mesh.importer ?? null,
      profileBasis: profile.basis ?? 'caller-supplied effective settings',
      settingsSha256: await digest(encoder.encode(JSON.stringify(sorted(config)))),
      geometrySha256: await digest(bytes),
      sourceToPlate: prepared.sourceToPlate,
      support: request.support,
      view,
      virtualBedExpanded,
      extractorVersion: 3,
    };
    const generationKey = await digest(encoder.encode(JSON.stringify(sorted(provenance))));
    if (request.support === 'none' && view === 'supports')
      return {
        schemaVersion: 1,
        generationKey,
        status: 'disabled',
        view,
        segments: new Float64Array(),
        layers: [],
        segmentCount: 0,
        bounds: prepared.bounds,
        sourceToPlate: prepared.sourceToPlate,
        provenance,
        warnings: [],
        time: null,
      };
    const job = encoder.encode(
      JSON.stringify({
        config,
        options: { validate: true, dropToBed: false },
        objects: [
          {
            name: 'preview',
            vertexOffset: 0,
            vertexCount: prepared.positions.length / 3,
            indexOffset: prepared.positions.byteLength,
            triangleCount: prepared.indices.length / 3,
            transform: prepared.sourceToPlate,
          },
        ],
      }),
    );
    const module = this.module;
    const allocations = [],
      outputs = [];
    const allocate = (size) => {
      const pointer = module._malloc(size);
      if (!pointer) throw new PreviewError('out_of_memory', 'Could not allocate browser engine input');
      allocations.push(pointer);
      return pointer;
    };
    const started = performance.now();
    try {
      const jobPointer = allocate(job.length),
        blobPointer = allocate(bytes.length),
        out = allocate(16);
      module.HEAPU8.set(job, jobPointer);
      module.HEAPU8.set(bytes, blobPointer);
      module.HEAPU8.fill(0, out, out + 16);
      const rc = module._cs_slice(
        jobPointer,
        job.length,
        blobPointer,
        bytes.length,
        out,
        out + 4,
        out + 8,
        out + 12,
      );
      // Heap growth invalidates previously borrowed views. Read all output fields from the current heap.
      const fields = new Uint32Array(module.HEAPU8.buffer, out, 4).slice();
      const [gcodePointer, gcodeLength, reportPointer, reportLength] = fields;
      outputs.push(gcodePointer, reportPointer);
      requireValue(
        reportLength > 0 &&
          reportLength <= 4 * 1024 * 1024 &&
          reportPointer + reportLength <= module.HEAPU8.length,
        'invalid_runtime_output',
        'Invalid engine report',
      );
      const report = JSON.parse(
        decoder.decode(module.HEAPU8.subarray(reportPointer, reportPointer + reportLength)),
      );
      if (rc !== 0 || !report.ok)
        throw new PreviewError('generation_failed', report.error || 'Orca slicing failed', { report });
      requireValue(
        !report.substitutions?.length,
        'configuration_substitution',
        `Engine changed/ignored settings: ${(report.substitutions ?? []).join('; ')}`,
      );
      requireValue(
        gcodeLength > 0 &&
          gcodeLength <= limits.maxGcodeBytes &&
          gcodePointer + gcodeLength <= module.HEAPU8.length,
        'gcode_limit',
        'Generated output exceeds the browser budget',
      );
      const gcode = decoder.decode(module.HEAPU8.subarray(gcodePointer, gcodePointer + gcodeLength));
      this.onProgress({ stage: 'extracting', percent: 95, message: 'Preparing generated support view' });
      const paths =
        view === 'print' ? readPrintPaths(gcode, { limits }) : readSupportPaths(gcode, { limits });
      requireValue(
        view !== 'print' || paths.segmentCount > 0,
        'invalid_runtime_output',
        'No printed paths were generated',
      );
      const seconds = report.stats?.printTimeSec;
      return {
        schemaVersion: 1,
        generationKey,
        status: 'ready',
        view,
        ...paths,
        bounds: prepared.bounds,
        sourceToPlate: prepared.sourceToPlate,
        provenance,
        warnings: report.warnings ?? [],
        time:
          Number.isFinite(seconds) && seconds > 0
            ? {
                estimatedSeconds: seconds,
                basis: 'orca_gcode_processor',
                physicalCalibration: false,
                upperSeconds: null,
              }
            : null,
        computeMilliseconds: performance.now() - started,
      };
    } catch (error) {
      if (error instanceof PreviewError) throw error;
      throw new PreviewError(
        'engine_error',
        'The local support engine failed; try another profile or model',
        { reason: String(error) },
      );
    } finally {
      for (const pointer of outputs) if (pointer) module._cs_free(pointer);
      for (const pointer of allocations) module._free(pointer);
    }
  }
}
